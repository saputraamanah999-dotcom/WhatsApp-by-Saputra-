# 🚀 Cara Run di HP & Deploy ke Vercel

Panduan lengkap untuk:
1. Run aplikasi di HP dari komputer development
2. Deploy aplikasi ke Vercel (production-ready)

---

## 📱 Part 1: Run di HP (Local Network)

Anda bisa buka aplikasi di HP selama komputer & HP terhubung ke WiFi yang sama.

### Step 1: Pastikan komputer & server sudah jalan

Di komputer (laptop/PC), jalankan:
```bash
# Terminal 1 — Socket.io service (TIDAK PERLU lagi untuk versi Firebase!)
# Skip ini, karena kita pakai Firestore real-time listeners

# Terminal 2 — Next.js dev server
cd neobrutal-chat
bun run dev
```

Output:
```
▲ Next.js 16.1.3 (Turbopack)
- Local:        http://localhost:3000
- Network:      http://192.168.1.100:3000    ← INI IP HP Anda!
✓ Ready in xxx ms
```

**Catat IP address** yang muncul di baris "Network" (contoh: `192.168.1.100`).

### Step 2: Buka di HP

1. Pastikan HP terhubung ke **WiFi yang sama** dengan komputer
2. Buka browser di HP (Chrome/Safari)
3. Ketik: `http://192.168.1.100:3000` (ganti dengan IP komputer Anda)

### Step 3: Aktifkan PWA (Install ke Home Screen)

Untuk pengalaman seperti aplikasi native:

**Android (Chrome):**
1. Buka `http://192.168.1.100:3000` di Chrome
2. Menu (⋮) → **Install app** / **Add to Home screen**
3. Aplikasi akan muncul sebagai ikon di home screen

**iPhone (Safari):**
1. Buka `http://192.168.1.100:3000` di Safari
2. Tap tombol **Share** (kotak dengan panah ke atas)
3. Pilih **Add to Home Screen**
4. Tap **Add**

Sekarang aplikasi bisa dibuka dari home screen HP seperti aplikasi native.

### Step 4: Test fitur di HP

| Fitur | Status di HP |
|-------|--------------|
| Register/Login | ✅ |
| Chat DM | ✅ Real-time via Firestore onSnapshot |
| Global Chat | ✅ |
| Voice Note | ✅ (perlu izin mikrofon) |
| Voice Call | ✅ WebRTC (HTTPS wajib untuk produksi) |
| Video Call | ✅ WebRTC |
| Stories | ✅ |
| Group | ✅ |
| Channel | ✅ |
| Dark Mode | ✅ |

### ⚠️ Catatan tentang Voice/Video Call di HP

WebRTC butuh **HTTPS** untuk akses mikrofon/kamera. Di localhost jalan, tapi di HP (HTTP) browser akan block.

**Solusi untuk dev lokal:**
```bash
# Pakai ngrok untuk HTTPS tunneling
ngrok http 3000
# Akan dapat URL seperti https://abc123.ngrok.io
# Buka URL itu di HP
```

**Untuk production:** Deploy ke Vercel (HTTPS otomatis). Lihat Part 2.

---

## 🌐 Part 2: Deploy ke Vercel

Vercel adalah platform hosting gratis untuk Next.js. Aplikasi akan dapat HTTPS otomatis (penting untuk WebRTC & PWA).

### Step 1: Persiapan

**A. Buat akun Vercel** (gratis):
- Buka https://vercel.com
- Login dengan GitHub / GitLab / Bitbucket / Email

**B. Push project ke Git** (wajib untuk Vercel):
```bash
cd neobrutal-chat

# Inisialisasi git
git init

# Tambahkan semua file (kecuali node_modules, .next, service-account.json)
git add .

# Commit pertama
git commit -m "Neobrutal Chat - Firebase + Vercel ready"

# Buat repo di GitHub (https://github.com/new)
# Lalu push
git remote add origin https://github.com/USERNAME/neobrutal-chat.git
git branch -M main
git push -u origin main
```

⚠️ **PENTING:** Pastikan file `.gitignore` sudah berisi:
```
node_modules/
.next/
.env
service-account.json
*.log
```

### Step 2: Import Project di Vercel

1. Login ke https://vercel.com
2. Klik **Add New...** → **Project**
3. Pilih repository GitHub Anda (`neobrutal-chat`)
4. Klik **Import**

### Step 3: Konfigurasi Build

Vercel akan auto-detect Next.js. Tidak perlu ubah apapun di tab **Build and Output Settings**.

Pastikan:
- **Framework Preset**: Next.js
- **Build Command**: `bun run build` (atau `npm run build` kalau tidak pakai Bun)
- **Output Directory**: `.next`
- **Install Command**: `bun install` (atau `npm install`)

### Step 4: Setup Environment Variables (PENTING!)

Di halaman Vercel project, scroll ke bawah ke section **Environment Variables**.

Tambahkan **semua variabel ini** (klik "Add" untuk setiap variabel):

#### Variabel Firebase Client (PUBLIC — safe to expose):

| Key | Value |
|-----|-------|
| `NEXT_PUBLIC_FIREBASE_API_KEY` | `AIzaSyDrAYKLg_Go-UiqB3tmQbHEudQXYzKm3s0` |
| `NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN` | `projekwhattsaf.firebaseapp.com` |
| `NEXT_PUBLIC_FIREBASE_PROJECT_ID` | `projekwhattsaf` |
| `NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET` | `projekwhattsaf.firebasestorage.app` |
| `NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID` | `431649153198` |
| `NEXT_PUBLIC_FIREBASE_APP_ID` | `1:431649153198:web:bd08dc5ef06f6c44300d3f` |
| `NEXT_PUBLIC_FIREBASE_MEASUREMENT_ID` | `G-V61QGJ8BW2` |

#### Variabel Firebase Admin SDK (SERVER-ONLY — JANGAN expose ke client):

| Key | Value |
|-----|-------|
| `FIREBASE_SERVICE_ACCOUNT` | `<paste isi JSON service account>` |

**Cara dapat `FIREBASE_SERVICE_ACCOUNT` value:**

1. Buka https://console.firebase.google.com/ → project `projekwhattsaf`
2. Klik **⚙️ Project Settings** → tab **Service accounts**
3. Klik **Generate new private key** → download JSON
4. Buka file JSON dengan text editor
5. Copy **SEMUA isi** file (mulai dari `{` sampai `}`)
6. Paste sebagai value `FIREBASE_SERVICE_ACCOUNT` di Vercel

**Contoh format value:**
```
{"type":"service_account","project_id":"projekwhattsaf","private_key_id":"...","private_key":"-----BEGIN PRIVATE KEY-----\n...\n-----END PRIVATE KEY-----\n","client_email":"firebase-adminsdk-xxx@projekwhattsaf.iam.gserviceaccount.com","client_id":"...","auth_uri":"https://accounts.google.com/o/oauth2/auth","token_uri":"https://oauth2.googleapis.com/token","auth_provider_x509_cert_url":"https://www.googleapis.com/oauth2/v1/certs","client_x509_cert_url":"https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-xxx%40projekwhattsaf.iam.gserviceaccount.com"}
```

**Tips:** Untuk memastikan JSON valid (1 line), jalankan di komputer:
```bash
cd neobrutal-chat
node scripts/load-service-account.js
# Output: FIREBASE_SERVICE_ACCOUNT={"type":"service_account",...}
# Copy seluruh baris itu sebagai value di Vercel
```

### Step 5: Deploy!

1. Setelah semua env var ditambahkan, klik **Deploy**
2. Tunggu 2-3 menit (Vercel akan build & deploy)
3. Setelah selesai, Anda akan dapat URL seperti:
   - `https://neobrutal-chat-xxx.vercel.app`
4. Buka URL itu di browser

🎉 **Aplikasi Anda sudah live di internet dengan HTTPS!**

### Step 6: Setup Firebase untuk Vercel Domain

Saat aplikasi di-deploy ke Vercel, browser mungkin butuh setup Firebase Auth domain.

1. Buka https://console.firebase.google.com/ → project `projekwhattsaf`
2. Klik **Authentication** → tab **Settings**
3. Scroll ke **Authorized domains**
4. Klik **Add domain**
5. Tambahkan domain Vercel Anda: `neobrutal-chat-xxx.vercel.app`
6. Klik **Add**

### Step 7: Update Firestore Security Rules (jika perlu)

Sama seperti di development — pastikan rules sudah di-publish di Firebase Console. Lihat file `firestore.rules`.

### Step 8: Test Aplikasi di HP

Buka URL Vercel di HP:
```
https://neobrutal-chat-xxx.vercel.app
```

Karena sudah HTTPS:
- ✅ Voice/Video Call berfungsi penuh (WebRTC)
- ✅ Mikrofon & kamera bisa diakses
- ✅ PWA bisa di-install ke home screen
- ✅ Notifikasi push bisa aktif (dengan setup tambahan)

---

## 🔄 Update Aplikasi di Vercel

Setiap kali Anda push commit ke branch `main` di GitHub, Vercel akan **auto-deploy** versi baru.

```bash
# Edit code...
git add .
git commit -m "feat: tambah fitur baru"
git push
# Tunggu 2-3 menit, Vercel akan rebuild otomatis
```

---

## 🆘 Troubleshooting Vercel

### Error: "Missing or insufficient permissions" di production

**Penyebab:** Firestore security rules belum di-publish, atau Firebase Auth domain belum di-whitelist.

**Solusi:**
1. Firebase Console → Firestore → Rules → publish file `firestore.rules`
2. Firebase Console → Authentication → Settings → Authorized domains → add `xxx.vercel.app`

### Error: "FIREBASE_SERVICE_ACCOUNT env var not set"

**Penyebab:** Anda lupa set env var `FIREBASE_SERVICE_ACCOUNT` di Vercel.

**Solusi:**
1. Vercel Dashboard → Project Anda → tab **Settings**
2. Menu **Environment Variables**
3. Tambah `FIREBASE_SERVICE_ACCOUNT` dengan value JSON service account
4. **Redeploy**: Vercel Dashboard → Deployments → ⋮ pada deploy terbaru → **Redeploy**

### Voice/Video call gagal di production

**Penyebab:** TURN server open relay (metered.ca) limit bandwidth, atau browser block.

**Solusi:**
1. Setup TURN server sendiri (Coturn di VPS)
2. Edit `src/lib/webrtc.ts` → ganti ICE config
3. Redeploy ke Vercel

### Build gagal di Vercel

**Penyebab:** Biasanya TypeScript error atau env var kurang.

**Solusi:**
1. Cek log build di Vercel Dashboard → Deployments → klik deploy yang gagal → tab **Build Logs**
2. Fix error di code lokal
3. `git push` untuk trigger rebuild

### Real-time chat tidak update

**Penyebab:** Firestore listeners tidak jalan, biasanya karena security rules block.

**Solusi:**
1. Cek browser console (F12) untuk error Firestore
2. Pastikan security rules mengizinkan read/write untuk user yang login

---

## 📊 Vercel Free Tier Limits

- **Bandwidth**: 100 GB/bulan (cukup untuk ribuan user)
- **Build**: 6000 menit/bulan
- **Function execution**: 1 juta invocations/bulan
- **Static files**: unlimited

Untuk aplikasi chat dengan Firebase sebagai database, ini lebih dari cukup.

---

## 💡 Tips Optimasi Vercel

1. **Pakai Firestore onSnapshot di client** (sudah kita lakukan) — tidak bebankan Vercel functions
2. **Cache static assets** di CDN Vercel (otomatis)
3. **Pakai Edge Functions** untuk API yang ringan (opsional)
4. **Monitor usage** di Vercel Dashboard → tab **Usage**

---

## 🎯 Quick Deploy Checklist

- [ ] ZIP sudah diextract
- [ ] `bun install` sukses
- [ ] Firebase Console setup (Firestore + Auth + Storage + Rules)
- [ ] `service-account.json` di root project
- [ ] Aplikasi jalan di `localhost:3000`
- [ ] Git repo sudah dibuat & di-push ke GitHub
- [ ] Vercel project sudah di-import dari GitHub
- [ ] Semua env vars di-set di Vercel (NEXT_PUBLIC_FIREBASE_* + FIREBASE_SERVICE_ACCOUNT)
- [ ] Domain Vercel ditambahkan ke Firebase Authorized Domains
- [ ] Deploy sukses
- [ ] Test di HP via URL Vercel

---

Kalau ada error saat deploy, screenshot log build di Vercel dan kirim ke saya.
