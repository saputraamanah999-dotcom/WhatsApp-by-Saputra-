import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import { authOptions, isAdmin } from "@/lib/auth"
import { getServerSession } from "next-auth"

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session?.user || !isAdmin(session.user as any)) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 })
  }

  const [users, banned, verified, msgs, groups, channels, stories, reports, calls] = await Promise.all([
    db.user.count(),
    db.user.count({ where: { banned: true } }),
    db.user.count({ where: { verified: true } }),
    db.message.count(),
    db.group.count(),
    db.channel.count(),
    db.story.count(),
    db.report.count({ where: { status: "open" } }),
    db.call.count(),
  ])

  // Online = lastSeen within last 60s
  const online = await db.user.count({
    where: { lastSeen: { gt: new Date(Date.now() - 60000) } },
  })

  // New users today
  const today = new Date()
  today.setHours(0, 0, 0, 0)
  const newToday = await db.user.count({ where: { createdAt: { gt: today } } })

  // Messages today
  const msgsToday = await db.message.count({ where: { createdAt: { gt: today } } })

  // Messages per day for last 7 days
  const sevenDaysAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000)
  const recentMsgs = await db.message.findMany({
    where: { createdAt: { gt: sevenDaysAgo } },
    select: { createdAt: true },
  })
  const perDay: { day: string; count: number }[] = []
  for (let i = 6; i >= 0; i--) {
    const d = new Date(today.getTime() - i * 24 * 60 * 60 * 1000)
    const next = new Date(d.getTime() + 24 * 60 * 60 * 1000)
    const count = recentMsgs.filter((m) => m.createdAt >= d && m.createdAt < next).length
    perDay.push({ day: d.toLocaleDateString("id-ID", { weekday: "short", day: "numeric" }), count })
  }

  return NextResponse.json({
    totalUsers: users,
    onlineUsers: online,
    bannedUsers: banned,
    verifiedUsers: verified,
    newUsersToday: newToday,
    totalMessages: msgs,
    messagesToday: msgsToday,
    totalGroups: groups,
    totalChannels: channels,
    totalStories: stories,
    openReports: reports,
    totalCalls: calls,
    messagesPerDay: perDay,
  })
}
