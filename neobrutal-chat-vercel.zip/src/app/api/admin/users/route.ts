import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import { authOptions, isAdmin } from "@/lib/auth"
import { getServerSession } from "next-auth"

export async function GET(req: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user || !isAdmin(session.user as any)) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 })
  }

  const url = new URL(req.url)
  const q = url.searchParams.get("q")?.trim().toLowerCase() || ""

  const where = q
    ? { OR: [{ username: { contains: q } }, { email: { contains: q } }] }
    : {}

  const users = await db.user.findMany({
    where,
    select: {
      id: true, email: true, username: true, displayName: true,
      role: true, banned: true, verified: true, online: true, lastSeen: true, createdAt: true,
    },
    orderBy: { createdAt: "desc" },
    take: 100,
  })
  return NextResponse.json({ users })
}

export async function PATCH(req: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user || !isAdmin(session.user as any)) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 })
  }
  const adminUid = (session.user as any).id

  const body = await req.json()
  const { userId, action } = body as { userId: string; action: string }

  const target = await db.user.findUnique({ where: { id: userId } })
  if (!target) return NextResponse.json({ error: "User tidak ditemukan" }, { status: 404 })

  // Don't allow admin to act on superadmin (except themselves)
  if (target.role === "superadmin" && target.id !== adminUid) {
    const me = await db.user.findUnique({ where: { id: adminUid } })
    if (me?.role !== "superadmin") {
      return NextResponse.json({ error: "Tidak bisa mengubah superadmin" }, { status: 403 })
    }
  }

  const data: any = {}
  if (action === "ban") data.banned = true
  else if (action === "unban") data.banned = false
  else if (action === "verify") data.verified = true
  else if (action === "unverify") data.verified = false
  else if (action === "make_admin") data.role = "admin"
  else if (action === "make_user") data.role = "user"
  else return NextResponse.json({ error: "Invalid action" }, { status: 400 })

  await db.user.update({ where: { id: userId }, data })

  await db.auditLog.create({
    data: {
      actorId: adminUid,
      action,
      targetType: "user",
      targetId: userId,
    },
  })

  return NextResponse.json({ ok: true })
}
