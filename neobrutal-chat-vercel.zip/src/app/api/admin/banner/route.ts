import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import { authOptions, isAdmin } from "@/lib/auth"
import { getServerSession } from "next-auth"

export async function GET() {
  // Public config (banner)
  const banner = await db.appConfig.findUnique({ where: { key: "banner" } })
  let bannerData = null
  if (banner) {
    try { bannerData = JSON.parse(banner.value) } catch { bannerData = null }
  }
  return NextResponse.json({ banner: bannerData })
}

export async function POST(req: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user || !isAdmin(session.user as any)) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 })
  }
  const adminUid = (session.user as any).id

  const body = await req.json()
  const { text, active, kind } = body as { text: string; active: boolean; kind: string }

  const value = JSON.stringify({
    text: String(text || "").slice(0, 500),
    active: !!active,
    kind: kind || "info",
    updatedAt: Date.now(),
    updatedBy: adminUid,
  })

  await db.appConfig.upsert({
    where: { key: "banner" },
    update: { value },
    create: { id: "banner", key: "banner", value },
  })

  await db.auditLog.create({
    data: { actorId: adminUid, action: "set_banner", targetType: "config", targetId: "banner" },
  })

  return NextResponse.json({ ok: true })
}
