import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import { authOptions } from "@/lib/auth"
import { getServerSession } from "next-auth"
import { writeFile, mkdir } from "fs/promises"
import path from "path"
import { randomUUID } from "crypto"

const ALLOWED = {
  image: ["image/jpeg", "image/png", "image/webp", "image/gif"],
  video: ["video/mp4", "video/webm"],
  audio: ["audio/mp3", "audio/webm", "audio/ogg", "audio/wav", "audio/mpeg"],
  document: ["application/pdf", "text/plain"],
}
const MAX_SIZE = 15 * 1024 * 1024 // 15MB

function detectKind(mime: string): "image" | "video" | "audio" | "document" | null {
  for (const [k, list] of Object.entries(ALLOWED)) {
    if (list.includes(mime)) return k as any
  }
  return null
}

export async function POST(req: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const uid = (session.user as any).id

  const formData = await req.formData()
  const file = formData.get("file") as File | null
  if (!file) return NextResponse.json({ error: "File required" }, { status: 400 })

  if (file.size > MAX_SIZE) {
    return NextResponse.json({ error: "File terlalu besar (max 15MB)" }, { status: 400 })
  }

  const kind = detectKind(file.type)
  if (!kind) {
    return NextResponse.json({ error: "Tipe file tidak didukung: " + file.type }, { status: 400 })
  }

  const ext = file.name.split(".").pop() || kind
  const filename = `${kind}_${randomUUID()}.${ext}`
  const dir = path.join(process.cwd(), "public", "uploads", kind)
  await mkdir(dir, { recursive: true })
  const filepath = path.join(dir, filename)
  const buf = Buffer.from(await file.arrayBuffer())
  await writeFile(filepath, buf)

  return NextResponse.json({
    url: `/uploads/${kind}/${filename}`,
    type: file.type,
    size: file.size,
    kind,
  })
}
