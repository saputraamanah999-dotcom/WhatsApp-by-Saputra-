import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import { authOptions } from "@/lib/auth"
import { getServerSession } from "next-auth"

export async function POST(req: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const uid = (session.user as any).id

  const body = await req.json()
  const { targetType, targetId, reason, description } = body as {
    targetType: string; targetId: string; reason: string; description?: string
  }

  if (!targetType || !targetId || !reason) {
    return NextResponse.json({ error: "missing fields" }, { status: 400 })
  }

  const report = await db.report.create({
    data: {
      reporterId: uid,
      targetType,
      targetId,
      reason,
      description: description || null,
      status: "open",
    },
  })
  return NextResponse.json({ report })
}
