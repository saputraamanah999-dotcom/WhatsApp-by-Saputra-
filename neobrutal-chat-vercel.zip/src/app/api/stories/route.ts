import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import { authOptions } from "@/lib/auth"
import { getServerSession } from "next-auth"

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const now = new Date()
  const stories = await db.story.findMany({
    where: { expiresAt: { gt: now } },
    include: {
      owner: { select: { id: true, username: true, displayName: true, photoURL: true, verified: true } },
      viewers: { select: { viewerId: true } },
      reactions: { select: { userId: true, emoji: true } },
    },
    orderBy: { createdAt: "desc" },
  })
  return NextResponse.json({ stories })
}

export async function POST(req: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const uid = (session.user as any).id

  const body = await req.json()
  const type = body.type || "text"
  const text = String(body.text || "").slice(0, 500)
  const mediaURL = body.mediaURL || null
  const bg = body.bg || "#8b5cf6"
  const duration = Math.min(Math.max(parseInt(body.duration) || 5, 3), 30)
  const audience = body.audience || "all"

  if (!text && !mediaURL) return NextResponse.json({ error: "Empty story" }, { status: 400 })

  const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000)
  const story = await db.story.create({
    data: {
      ownerId: uid,
      type,
      text: text || null,
      mediaURL,
      bg,
      duration,
      audience,
      expiresAt,
    },
    include: {
      owner: { select: { id: true, username: true, displayName: true, photoURL: true, verified: true } },
    },
  })
  return NextResponse.json({ story })
}

export async function DELETE(req: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const uid = (session.user as any).id

  const url = new URL(req.url)
  const id = url.searchParams.get("id")
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 })

  const story = await db.story.findUnique({ where: { id } })
  if (!story) return NextResponse.json({ error: "Not found" }, { status: 404 })
  if (story.ownerId !== uid) {
    const me = await db.user.findUnique({ where: { id: uid }, select: { role: true } })
    if (me?.role !== "admin" && me?.role !== "superadmin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }
  }
  await db.story.delete({ where: { id } })
  return NextResponse.json({ ok: true })
}
