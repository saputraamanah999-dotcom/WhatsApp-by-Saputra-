import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import { authOptions } from "@/lib/auth"
import { getServerSession } from "next-auth"

export async function POST(req: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const uid = (session.user as any).id

  const body = await req.json()
  const { storyId } = body as { storyId: string }
  if (!storyId) return NextResponse.json({ error: "storyId required" }, { status: 400 })

  try {
    await db.storyView.upsert({
      where: { storyId_viewerId: { storyId, viewerId: uid } },
      update: {},
      create: { storyId, viewerId: uid },
    })
  } catch (e) {
    // ignore duplicates
  }
  return NextResponse.json({ ok: true })
}
