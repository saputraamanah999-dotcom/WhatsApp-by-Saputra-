import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import { authOptions } from "@/lib/auth"
import { getServerSession } from "next-auth"

export async function POST(req: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const uid = (session.user as any).id

  const body = await req.json()
  const { storyId, emoji } = body as { storyId: string; emoji: string }
  if (!storyId || !emoji) return NextResponse.json({ error: "missing" }, { status: 400 })

  try {
    await db.storyReaction.upsert({
      where: { storyId_userId: { storyId, userId: uid } },
      update: { emoji },
      create: { storyId, userId: uid, emoji },
    })
  } catch (e) {
    // ignore
  }
  return NextResponse.json({ ok: true })
}
