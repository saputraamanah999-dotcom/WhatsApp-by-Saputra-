import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import { authOptions, isAdmin } from "@/lib/auth"
import { getServerSession } from "next-auth"
import { normalizeUsername } from "@/lib/utils"

export async function GET(req: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const url = new URL(req.url)
  const q = url.searchParams.get("q")?.trim().toLowerCase() || ""
  const mine = url.searchParams.get("mine") === "1"

  if (mine) {
    const me = await db.user.findUnique({
      where: { id: (session.user as any).id },
      select: {
        id: true, username: true, displayName: true, bio: true, photoURL: true,
        verified: true, role: true, online: true, lastSeen: true, createdAt: true, email: true,
      },
    })
    return NextResponse.json({ user: me })
  }

  if (q) {
    const users = await db.user.findMany({
      where: {
        AND: [
          { banned: false },
          {
            OR: [
              { username: { contains: q } },
              { displayName: { contains: q } },
            ],
          },
        ],
      },
      select: {
        id: true, username: true, displayName: true, photoURL: true,
        verified: true, online: true, lastSeen: true, bio: true,
      },
      take: 30,
    })
    return NextResponse.json({ users })
  }

  const users = await db.user.findMany({
    where: { banned: false, NOT: { id: (session.user as any).id } },
    select: {
      id: true, username: true, displayName: true, photoURL: true,
      verified: true, online: true, lastSeen: true,
    },
    orderBy: { online: "desc" },
    take: 50,
  })
  return NextResponse.json({ users })
}

export async function PATCH(req: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const body = await req.json()
  const uid = (session.user as any).id

  const data: any = {}
  if (typeof body.displayName === "string" && body.displayName.length <= 30) {
    data.displayName = body.displayName.trim()
  }
  if (typeof body.bio === "string" && body.bio.length <= 160) {
    data.bio = body.bio.trim()
  }
  if (typeof body.photoURL === "string") {
    data.photoURL = body.photoURL
  }
  if (typeof body.username === "string") {
    const newUname = normalizeUsername(body.username)
    if (!/^[a-z0-9_]{3,20}$/.test(newUname)) {
      return NextResponse.json({ error: "Username tidak valid (3-20 karakter, huruf kecil, angka, _)" }, { status: 400 })
    }
    const existing = await db.user.findUnique({ where: { username: newUname } })
    if (existing && existing.id !== uid) {
      return NextResponse.json({ error: "Username sudah dipakai" }, { status: 400 })
    }
    data.username = newUname
  }

  await db.user.update({ where: { id: uid }, data })
  return NextResponse.json({ ok: true })
}
