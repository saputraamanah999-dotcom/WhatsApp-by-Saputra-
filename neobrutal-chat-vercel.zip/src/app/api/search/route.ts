import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import { authOptions } from "@/lib/auth"
import { getServerSession } from "next-auth"

export async function GET(req: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const url = new URL(req.url)
  const q = url.searchParams.get("q")?.trim().toLowerCase() || ""
  if (!q || q.length < 2) return NextResponse.json({ users: [], groups: [], channels: [] })

  const [users, groups, channels] = await Promise.all([
    db.user.findMany({
      where: { AND: [{ banned: false }, { OR: [{ username: { contains: q } }, { displayName: { contains: q } }] }] },
      select: { id: true, username: true, displayName: true, photoURL: true, verified: true, online: true, lastSeen: true, bio: true },
      take: 20,
    }),
    db.group.findMany({
      where: { visibility: "public", OR: [{ name: { contains: q } }, { description: { contains: q } }] },
      take: 20,
    }),
    db.channel.findMany({
      where: { OR: [{ name: { contains: q } }, { slug: { contains: q } }, { description: { contains: q } }] },
      take: 20,
    }),
  ])

  return NextResponse.json({ users, groups, channels })
}
