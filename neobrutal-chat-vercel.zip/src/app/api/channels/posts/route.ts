import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import { authOptions } from "@/lib/auth"
import { getServerSession } from "next-auth"

export async function GET(req: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const url = new URL(req.url)
  const channelId = url.searchParams.get("channelId")
  if (!channelId) return NextResponse.json({ error: "channelId required" }, { status: 400 })

  const posts = await db.channelPost.findMany({
    where: { channelId },
    orderBy: { createdAt: "desc" },
    take: 50,
    include: { author: { select: { username: true, displayName: true, photoURL: true, verified: true } } },
  })
  return NextResponse.json({
    posts: posts.map((p) => ({
      id: p.id,
      channelId: p.channelId,
      authorId: p.authorId,
      authorUsername: p.author?.username || "",
      authorDisplayName: p.author?.displayName || "",
      authorPhoto: p.author?.photoURL || null,
      authorVerified: p.author?.verified || false,
      text: p.text,
      mediaURL: p.mediaURL,
      mediaType: p.mediaType,
      pinned: p.pinned,
      viewCount: p.viewCount,
      reactions: p.reactions,
      createdAt: p.createdAt,
    })),
  })
}

export async function POST(req: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const uid = (session.user as any).id

  const body = await req.json()
  const channelId = body.channelId
  const text = String(body.text || "").trim().slice(0, 5000)
  const mediaURL = body.mediaURL || null
  const mediaType = body.mediaType || null

  if (!channelId) return NextResponse.json({ error: "channelId required" }, { status: 400 })
  if (!text && !mediaURL) return NextResponse.json({ error: "Empty" }, { status: 400 })

  const channel = await db.channel.findUnique({ where: { id: channelId } })
  if (!channel) return NextResponse.json({ error: "Channel tidak ditemukan" }, { status: 404 })
  if (channel.ownerId !== uid) {
    return NextResponse.json({ error: "Hanya pemilik channel yang bisa memposting" }, { status: 403 })
  }

  const post = await db.channelPost.create({
    data: { channelId, authorId: uid, text, mediaURL, mediaType },
    include: { author: { select: { username: true, displayName: true, photoURL: true, verified: true } } },
  })

  return NextResponse.json({
    post: {
      id: post.id,
      channelId: post.channelId,
      authorId: post.authorId,
      authorUsername: post.author?.username || "",
      authorDisplayName: post.author?.displayName || "",
      authorPhoto: post.author?.photoURL || null,
      authorVerified: post.author?.verified || false,
      text: post.text,
      mediaURL: post.mediaURL,
      mediaType: post.mediaType,
      pinned: post.pinned,
      viewCount: post.viewCount,
      reactions: post.reactions,
      createdAt: post.createdAt,
    },
  })
}
