import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import { authOptions } from "@/lib/auth"
import { getServerSession } from "next-auth"

export async function POST(req: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const uid = (session.user as any).id

  const body = await req.json()
  const { channelId } = body as { channelId: string }
  if (!channelId) return NextResponse.json({ error: "channelId required" }, { status: 400 })

  const existing = await db.channelFollow.findUnique({
    where: { channelId_userId: { channelId, userId: uid } },
  })
  if (existing) return NextResponse.json({ ok: true, following: true })

  await db.channelFollow.create({ data: { channelId, userId: uid } })
  await db.channel.update({ where: { id: channelId }, data: { followerCount: { increment: 1 } } })
  return NextResponse.json({ ok: true, following: true })
}

export async function DELETE(req: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const uid = (session.user as any).id

  const url = new URL(req.url)
  const channelId = url.searchParams.get("channelId")
  if (!channelId) return NextResponse.json({ error: "channelId required" }, { status: 400 })

  await db.channelFollow.deleteMany({ where: { channelId, userId: uid } })
  await db.channel.update({ where: { id: channelId }, data: { followerCount: { decrement: 1 } } })
  return NextResponse.json({ ok: true, following: false })
}
