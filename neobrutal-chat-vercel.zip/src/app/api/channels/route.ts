import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import { authOptions } from "@/lib/auth"
import { getServerSession } from "next-auth"
import { slugify } from "@/lib/utils"

export async function GET(req: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const url = new URL(req.url)
  const q = url.searchParams.get("q")?.trim().toLowerCase() || ""
  const followed = url.searchParams.get("followed") === "1"

  const uid = (session.user as any).id

  if (followed) {
    const follows = await db.channelFollow.findMany({
      where: { userId: uid },
      include: { channel: { include: { owner: { select: { username: true, displayName: true, photoURL: true, verified: true } } } } },
      orderBy: { createdAt: "desc" },
    })
    return NextResponse.json({ channels: follows.map((f) => f.channel) })
  }

  const where = q ? { name: { contains: q } } : {}
  const channels = await db.channel.findMany({
    where,
    include: { owner: { select: { username: true, displayName: true, photoURL: true, verified: true } } },
    take: 50,
    orderBy: { followerCount: "desc" },
  })
  return NextResponse.json({ channels })
}

export async function POST(req: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const uid = (session.user as any).id

  const body = await req.json()
  const name = String(body.name || "").trim().slice(0, 50)
  const description = String(body.description || "").trim().slice(0, 500)
  let slug = slugify(body.slug || name)
  if (!slug) slug = "ch_" + Date.now().toString(36)

  if (!name) return NextResponse.json({ error: "Nama channel wajib diisi" }, { status: 400 })

  const exists = await db.channel.findUnique({ where: { slug } })
  if (exists) return NextResponse.json({ error: "Slug sudah dipakai" }, { status: 400 })

  const channel = await db.channel.create({
    data: {
      name,
      slug,
      description,
      ownerId: uid,
    },
  })
  // Auto-follow own channel
  await db.channelFollow.create({ data: { channelId: channel.id, userId: uid } })
  await db.channel.update({ where: { id: channel.id }, data: { followerCount: { increment: 1 } } })
  return NextResponse.json({ channel })
}
