import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import { authOptions } from "@/lib/auth"
import { getServerSession } from "next-auth"

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const uid = (session.user as any).id

  const notifications = await db.notification.findMany({
    where: { recipientId: uid },
    orderBy: { createdAt: "desc" },
    take: 50,
  })
  return NextResponse.json({ notifications })
}

export async function PATCH(req: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const uid = (session.user as any).id

  const body = await req.json()
  const { all } = body as { all?: boolean }
  if (all) {
    await db.notification.updateMany({
      where: { recipientId: uid, read: false },
      data: { read: true },
    })
    return NextResponse.json({ ok: true })
  }
  const { id } = body
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 })
  await db.notification.updateMany({
    where: { id, recipientId: uid },
    data: { read: true },
  })
  return NextResponse.json({ ok: true })
}
