import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import { authOptions } from "@/lib/auth"
import { getServerSession } from "next-auth"
import { parseMentions } from "@/lib/utils"

export async function GET(req: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const url = new URL(req.url)
  const groupId = url.searchParams.get("groupId")
  if (!groupId) return NextResponse.json({ error: "groupId required" }, { status: 400 })

  const msgs = await db.groupMessage.findMany({
    where: { groupId },
    orderBy: { createdAt: "asc" },
    take: 200,
    include: { sender: { select: { username: true, displayName: true, photoURL: true, verified: true } } },
  })
  return NextResponse.json({
    messages: msgs.map((m) => ({
      id: m.id,
      senderId: m.senderId,
      senderUsername: m.sender?.username || "",
      senderDisplayName: m.sender?.displayName || "",
      senderPhoto: m.sender?.photoURL || null,
      senderVerified: m.sender?.verified || false,
      text: m.text,
      type: m.type,
      mediaURL: m.mediaURL,
      reactions: m.reactions,
      replyToId: m.replyToId,
      createdAt: m.createdAt,
    })),
  })
}

export async function POST(req: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const uid = (session.user as any).id

  const body = await req.json()
  const groupId = body.groupId
  const text = String(body.text || "").trim().slice(0, 5000)
  const type = body.type || "text"
  const mediaURL = body.mediaURL || null
  const replyToId = body.replyToId || null

  if (!groupId) return NextResponse.json({ error: "groupId required" }, { status: 400 })
  if (!text && !mediaURL) return NextResponse.json({ error: "Empty" }, { status: 400 })

  const member = await db.groupMember.findUnique({
    where: { groupId_userId: { groupId, userId: uid } },
  })
  if (!member) return NextResponse.json({ error: "Bukan anggota grup" }, { status: 403 })

  const user = await db.user.findUnique({ where: { id: uid }, select: { username: true, banned: true } })
  if (user?.banned) return NextResponse.json({ error: "Dibanned" }, { status: 403 })

  const msg = await db.groupMessage.create({
    data: {
      groupId,
      senderId: uid,
      text,
      type,
      mediaURL,
      replyToId,
      reactions: "{}",
    },
  })

  return NextResponse.json({
    message: {
      id: msg.id,
      groupId: msg.groupId,
      senderId: uid,
      senderUsername: user?.username || "",
      text: msg.text,
      type: msg.type,
      mediaURL: msg.mediaURL,
      createdAt: msg.createdAt,
      replyToId: msg.replyToId,
      mentions: parseMentions(text),
    },
  })
}
