import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import { authOptions } from "@/lib/auth"
import { getServerSession } from "next-auth"

export async function GET(req: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const uid = (session.user as any).id

  const url = new URL(req.url)
  const groupId = url.searchParams.get("groupId")
  if (!groupId) return NextResponse.json({ error: "groupId required" }, { status: 400 })

  const members = await db.groupMember.findMany({
    where: { groupId },
    include: { user: { select: { id: true, username: true, displayName: true, photoURL: true, verified: true, online: true, lastSeen: true } } },
    orderBy: { joinedAt: "asc" },
  })
  return NextResponse.json({ members })
}

export async function POST(req: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const uid = (session.user as any).id

  const body = await req.json()
  const { groupId, inviteCode } = body as { groupId: string; inviteCode?: string }

  const group = await db.group.findUnique({ where: { id: groupId } })
  if (!group) return NextResponse.json({ error: "Grup tidak ditemukan" }, { status: 404 })

  if (group.visibility === "private") {
    if (!inviteCode || inviteCode !== group.inviteCode) {
      return NextResponse.json({ error: "Kode undangan tidak valid" }, { status: 403 })
    }
  }

  const existing = await db.groupMember.findUnique({
    where: { groupId_userId: { groupId, userId: uid } },
  })
  if (existing) return NextResponse.json({ error: "Sudah bergabung" }, { status: 400 })

  await db.groupMember.create({ data: { groupId, userId: uid, role: "member" } })
  await db.group.update({ where: { id: groupId }, data: { memberCount: { increment: 1 } } })
  return NextResponse.json({ ok: true })
}

export async function DELETE(req: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const uid = (session.user as any).id

  const url = new URL(req.url)
  const groupId = url.searchParams.get("groupId")
  if (!groupId) return NextResponse.json({ error: "groupId required" }, { status: 400 })

  const existing = await db.groupMember.findUnique({
    where: { groupId_userId: { groupId, userId: uid } },
  })
  if (!existing) return NextResponse.json({ error: "Bukan anggota" }, { status: 400 })

  if (existing.role === "owner") {
    // Owner leaves → delete group
    await db.group.delete({ where: { id: groupId } })
  } else {
    await db.groupMember.delete({ where: { id: existing.id } })
    await db.group.update({ where: { id: groupId }, data: { memberCount: { decrement: 1 } } })
  }
  return NextResponse.json({ ok: true })
}
