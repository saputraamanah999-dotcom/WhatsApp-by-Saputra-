import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import { authOptions } from "@/lib/auth"
import { getServerSession } from "next-auth"
import { genInviteCode, slugify } from "@/lib/utils"

export async function GET(req: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const url = new URL(req.url)
  const q = url.searchParams.get("q")?.trim().toLowerCase() || ""

  if (q) {
    const groups = await db.group.findMany({
      where: { visibility: "public", name: { contains: q } },
      include: { owner: { select: { username: true, displayName: true, photoURL: true, verified: true } } },
      take: 30,
      orderBy: { memberCount: "desc" },
    })
    return NextResponse.json({ groups })
  }

  const groups = await db.group.findMany({
    where: { visibility: "public" },
    include: { owner: { select: { username: true, displayName: true, photoURL: true, verified: true } } },
    orderBy: { memberCount: "desc" },
    take: 50,
  })
  return NextResponse.json({ groups })
}

export async function POST(req: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const uid = (session.user as any).id

  const body = await req.json()
  const name = String(body.name || "").trim().slice(0, 50)
  const description = String(body.description || "").trim().slice(0, 500)
  const visibility = body.visibility === "private" ? "private" : "public"
  const joinPolicy = body.joinPolicy === "approval" ? "approval" : "open"

  if (!name) return NextResponse.json({ error: "Nama grup wajib diisi" }, { status: 400 })

  const group = await db.group.create({
    data: {
      name,
      description,
      ownerId: uid,
      visibility,
      joinPolicy,
      inviteCode: genInviteCode(),
      memberCount: 1,
    },
  })
  await db.groupMember.create({
    data: { groupId: group.id, userId: uid, role: "owner" },
  })
  return NextResponse.json({ group })
}
