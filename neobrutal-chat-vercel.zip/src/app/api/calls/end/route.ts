import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import { authOptions } from "@/lib/auth"
import { getServerSession } from "next-auth"

export async function POST(req: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const uid = (session.user as any).id

  const body = await req.json()
  const { callId, status, durationSeconds } = body as {
    callId: string
    status: string
    durationSeconds?: number
  }

  if (!callId || !status) return NextResponse.json({ error: "missing" }, { status: 400 })

  const call = await db.call.findUnique({ where: { id: callId } })
  if (!call) return NextResponse.json({ error: "Not found" }, { status: 404 })
  if (call.callerId !== uid && call.calleeId !== uid) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 })
  }

  const data: any = { status }
  if (status === "active" && !call.startedAt) data.startedAt = new Date()
  if (status === "ended" || status === "missed" || status === "rejected" || status === "failed") {
    data.endedAt = new Date()
    if (durationSeconds !== undefined) data.durationSeconds = durationSeconds
  }

  await db.call.update({ where: { id: callId }, data })
  return NextResponse.json({ ok: true })
}
