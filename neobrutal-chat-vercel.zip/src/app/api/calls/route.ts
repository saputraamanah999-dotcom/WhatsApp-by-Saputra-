import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import { authOptions } from "@/lib/auth"
import { getServerSession } from "next-auth"

// Get call history
export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const uid = (session.user as any).id

  const calls = await db.call.findMany({
    where: { OR: [{ callerId: uid }, { calleeId: uid }] },
    orderBy: { createdAt: "desc" },
    take: 50,
    include: {
      caller: { select: { username: true, displayName: true, photoURL: true } },
      callee: { select: { username: true, displayName: true, photoURL: true } },
    },
  })
  return NextResponse.json({ calls })
}

// Create call record
export async function POST(req: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const uid = (session.user as any).id

  const body = await req.json()
  const { calleeId, callType } = body as { calleeId: string; callType: string }

  if (!calleeId) return NextResponse.json({ error: "calleeId required" }, { status: 400 })

  const call = await db.call.create({
    data: {
      callerId: uid,
      calleeId,
      callType: callType === "video" ? "video" : "voice",
      status: "ringing",
    },
  })
  return NextResponse.json({ call })
}
