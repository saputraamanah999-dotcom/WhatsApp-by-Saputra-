// Stories API (Firebase)
import { NextResponse } from "next/server"
import { getAdminDb, ensureAdminSignedIn } from "@/lib/firebase-server"
import { getCurrentUid, isAdminRole } from "@/lib/session"

export async function GET() {
  await ensureAdminSignedIn()
  const adminDb = getAdminDb()
  if (!adminDb) return NextResponse.json({ error: "Firestore not configured" }, { status: 500 })

  const now = Date.now()
  const snap = await adminDb
    .collection("stories")
    .where("expiresAt", ">", now)
    .orderBy("expiresAt", "desc")
    .get()

  const stories: any[] = []
  for (const doc of snap.docs) {
    const d = doc.data()
    const ownerDoc = await adminDb.collection("users").doc(d.ownerId).get()
    const owner = ownerDoc.exists ? ownerDoc.data()! : null
    const viewersSnap = await adminDb.collection("stories").doc(doc.id).collection("viewers").get()
    const viewers = viewersSnap.docs.map((v) => ({ viewerId: v.id }))
    const reactionsSnap = await adminDb.collection("stories").doc(doc.id).collection("reactions").get()
    const reactions = reactionsSnap.docs.map((r) => ({ userId: r.id, emoji: r.data()!.emoji }))
    stories.push({
      id: doc.id,
      ownerId: d.ownerId,
      owner: {
        id: ownerDoc.id,
        username: owner?.username,
        displayName: owner?.displayName,
        photoURL: owner?.photoURL,
        verified: owner?.verified || false,
      },
      type: d.type,
      text: d.text,
      mediaURL: d.mediaURL,
      bg: d.bg,
      duration: d.duration,
      audience: d.audience,
      expiresAt: d.expiresAt,
      createdAt: d.createdAt,
      viewers,
      reactions,
    })
  }
  return NextResponse.json({ stories })
}

export async function POST(req: Request) {
  const uid = await getCurrentUid(req)
  if (!uid) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const body = await req.json()
  const type = body.type || "text"
  const text = String(body.text || "").slice(0, 500)
  const mediaURL = body.mediaURL || null
  const bg = body.bg || "#8b5cf6"
  const duration = Math.min(Math.max(parseInt(body.duration) || 5, 3), 30)
  const audience = body.audience || "all"

  if (!text && !mediaURL) return NextResponse.json({ error: "Empty story" }, { status: 400 })

  await ensureAdminSignedIn()
  const adminDb = getAdminDb()
  if (!adminDb) return NextResponse.json({ error: "Firestore not configured" }, { status: 500 })

  const expiresAt = Date.now() + 24 * 60 * 60 * 1000
  const ref = await adminDb.collection("stories").add({
    ownerId: uid,
    type,
    text: text || null,
    mediaURL,
    bg,
    duration,
    audience,
    expiresAt,
    createdAt: Date.now(),
  })
  const doc = await ref.get()
  const d = doc.data()!
  const ownerDoc = await adminDb.collection("users").doc(uid).get()
  const owner = ownerDoc.data()!
  return NextResponse.json({
    story: {
      id: doc.id,
      ownerId: uid,
      owner: {
        id: uid,
        username: owner.username,
        displayName: owner.displayName,
        photoURL: owner.photoURL,
        verified: owner.verified || false,
      },
      type: d.type,
      text: d.text,
      mediaURL: d.mediaURL,
      bg: d.bg,
      duration: d.duration,
      audience: d.audience,
      expiresAt: d.expiresAt,
      createdAt: d.createdAt,
    },
  })
}

export async function DELETE(req: Request) {
  const uid = await getCurrentUid(req)
  if (!uid) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  await ensureAdminSignedIn()
  const adminDb = getAdminDb()
  if (!adminDb) return NextResponse.json({ error: "Firestore not configured" }, { status: 500 })

  const url = new URL(req.url)
  const id = url.searchParams.get("id")
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 })

  const ref = adminDb.collection("stories").doc(id)
  const doc = await ref.get()
  if (!doc.exists) return NextResponse.json({ error: "Not found" }, { status: 404 })

  if (doc.data()!.ownerId !== uid) {
    const userDoc = await adminDb.collection("users").doc(uid).get()
    if (!isAdminRole(userDoc.data())) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }
  }
  await ref.delete()
  return NextResponse.json({ ok: true })
}
