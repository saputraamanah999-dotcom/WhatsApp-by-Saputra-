import { NextResponse } from "next/server"
import { getAdminDb, ensureAdminSignedIn } from "@/lib/firebase-server"
import { getCurrentUid } from "@/lib/session"

export async function POST(req: Request) {
  const uid = await getCurrentUid(req)
  if (!uid) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const body = await req.json()
  const { storyId } = body as { storyId: string }
  if (!storyId) return NextResponse.json({ error: "storyId required" }, { status: 400 })

  await ensureAdminSignedIn()
  const adminDb = getAdminDb()
  if (!adminDb) return NextResponse.json({ error: "Firestore not configured" }, { status: 500 })

  await adminDb
    .collection("stories")
    .doc(storyId)
    .collection("viewers")
    .doc(uid)
    .set({ viewedAt: Date.now() }, { merge: true })
  return NextResponse.json({ ok: true })
}
