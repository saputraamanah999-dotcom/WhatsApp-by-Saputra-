// Admin banner API (Firebase)
import { NextResponse } from "next/server"
import { getAdminDb, ensureAdminSignedIn } from "@/lib/firebase-server"
import { getCurrentUid, isAdminRole } from "@/lib/session"

export async function GET() {
  await ensureAdminSignedIn()
  const adminDb = getAdminDb()
  if (!adminDb) return NextResponse.json({ error: "Firestore not configured" }, { status: 500 })

  const doc = await adminDb.collection("config").doc("banner").get()
  if (!doc.exists) return NextResponse.json({ banner: null })
  return NextResponse.json({ banner: doc.data() })
}

export async function POST(req: Request) {
  const uid = await getCurrentUid(req)
  if (!uid) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  await ensureAdminSignedIn()
  const adminDb = getAdminDb()
  if (!adminDb) return NextResponse.json({ error: "Firestore not configured" }, { status: 500 })

  const adminDoc = await adminDb.collection("users").doc(uid).get()
  if (!isAdminRole(adminDoc.data())) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 })
  }

  const body = await req.json()
  const { text, active, kind } = body as { text: string; active: boolean; kind: string }

  const value = {
    text: String(text || "").slice(0, 500),
    active: !!active,
    kind: kind || "info",
    updatedAt: Date.now(),
    updatedBy: uid,
  }

  await adminDb.collection("config").doc("banner").set(value, { merge: true })
  await adminDb.collection("auditLogs").add({
    actorId: uid,
    action: "set_banner",
    targetType: "config",
    targetId: "banner",
    timestamp: Date.now(),
  })

  return NextResponse.json({ ok: true })
}
