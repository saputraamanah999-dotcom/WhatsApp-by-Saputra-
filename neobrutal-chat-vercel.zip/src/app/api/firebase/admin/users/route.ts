// Admin Users API (Firebase)
import { NextResponse } from "next/server"
import { getAdminDb, getAdminAuthInstance, ensureAdminSignedIn } from "@/lib/firebase-server"
import { getCurrentUid, isAdminRole } from "@/lib/session"

export async function GET(req: Request) {
  const uid = await getCurrentUid(req)
  if (!uid) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  await ensureAdminSignedIn()
  const adminDb = getAdminDb()
  if (!adminDb) return NextResponse.json({ error: "Firestore not configured" }, { status: 500 })

  const userDoc = await adminDb.collection("users").doc(uid).get()
  if (!isAdminRole(userDoc.data())) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 })
  }

  const url = new URL(req.url)
  const q = url.searchParams.get("q")?.trim().toLowerCase() || ""

  const snap = await adminDb.collection("users").orderBy("createdAt", "desc").limit(100).get()
  const users = snap.docs
    .filter((doc) => {
      if (!q) return true
      const d = doc.data()
      return (d.username?.toLowerCase().includes(q)) || (d.email?.toLowerCase().includes(q))
    })
    .map((doc) => {
      const d = doc.data()
      return {
        id: doc.id,
        email: d.email,
        username: d.username,
        displayName: d.displayName,
        role: d.role || "user",
        banned: d.banned || false,
        verified: d.verified || false,
        online: d.online || false,
        lastSeen: d.lastSeen || 0,
        createdAt: d.createdAt || 0,
      }
    })
  return NextResponse.json({ users })
}

export async function PATCH(req: Request) {
  const uid = await getCurrentUid(req)
  if (!uid) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  await ensureAdminSignedIn()
  const adminDb = getAdminDb()
  if (!adminDb) return NextResponse.json({ error: "Firestore not configured" }, { status: 500 })

  const adminDoc = await adminDb.collection("users").doc(uid).get()
  if (!isAdminRole(adminDoc.data())) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 })
  }

  const body = await req.json()
  const { userId, action } = body as { userId: string; action: string }

  const targetDoc = await adminDb.collection("users").doc(userId).get()
  if (!targetDoc.exists) return NextResponse.json({ error: "User tidak ditemukan" }, { status: 404 })

  const targetData = targetDoc.data()!
  // Don't allow acting on superadmin (except themselves)
  if (targetData.role === "superadmin" && userId !== uid) {
    if (adminDoc.data()!.role !== "superadmin") {
      return NextResponse.json({ error: "Tidak bisa mengubah superadmin" }, { status: 403 })
    }
  }

  const data: any = { updatedAt: Date.now() }
  if (action === "ban") data.banned = true
  else if (action === "unban") data.banned = false
  else if (action === "verify") data.verified = true
  else if (action === "unverify") data.verified = false
  else if (action === "make_admin") data.role = "admin"
  else if (action === "make_user") data.role = "user"
  else return NextResponse.json({ error: "Invalid action" }, { status: 400 })

  await adminDb.collection("users").doc(userId).update(data)
  await adminDb.collection("auditLogs").add({
    actorId: uid,
    action,
    targetType: "user",
    targetId: userId,
    timestamp: Date.now(),
  })
  return NextResponse.json({ ok: true })
}
