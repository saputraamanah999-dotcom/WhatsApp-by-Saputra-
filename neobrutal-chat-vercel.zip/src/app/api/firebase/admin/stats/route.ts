// Admin stats API (Firebase)
import { NextResponse } from "next/server"
import { getAdminDb, ensureAdminSignedIn } from "@/lib/firebase-server"
import { getCurrentUid, isAdminRole } from "@/lib/session"

export async function GET() {
  const uid = await getCurrentUid()
  if (!uid) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  await ensureAdminSignedIn()
  const adminDb = getAdminDb()
  if (!adminDb) return NextResponse.json({ error: "Firestore not configured" }, { status: 500 })

  const adminDoc = await adminDb.collection("users").doc(uid).get()
  if (!isAdminRole(adminDoc.data())) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 })
  }

  const now = Date.now()
  const oneMinAgo = now - 60000
  const today = new Date()
  today.setHours(0, 0, 0, 0)
  const sevenDaysAgo = today.getTime() - 7 * 24 * 60 * 60 * 1000

  const [usersSnap, bannedSnap, verifiedSnap, msgsSnap, groupsSnap, channelsSnap, storiesSnap, callsSnap, onlineSnap, newTodaySnap, msgsTodaySnap] = await Promise.all([
    adminDb.collection("users").get(),
    adminDb.collection("users").where("banned", "==", true).get(),
    adminDb.collection("users").where("verified", "==", true).get(),
    adminDb.collection("dms").get(),
    adminDb.collection("groups").get(),
    adminDb.collection("channels").get(),
    adminDb.collection("stories").get(),
    adminDb.collection("calls").get(),
    adminDb.collection("users").where("online", "==", true).where("lastSeen", ">", oneMinAgo).get(),
    adminDb.collection("users").where("createdAt", ">", today.getTime()).get(),
    adminDb.collection("dms").where("createdAt", ">", today.getTime()).get(),
  ])

  // 7-day message activity
  const perDay: { day: string; count: number }[] = []
  // Aggregate from msgsSnap (might be slow with many messages; for demo it's fine)
  for (let i = 6; i >= 0; i--) {
    const d = new Date(today.getTime() - i * 24 * 60 * 60 * 1000)
    const next = new Date(d.getTime() + 24 * 60 * 60 * 1000)
    const count = msgsSnap.docs.filter((doc) => {
      const ts = doc.data().createdAt
      return ts >= d.getTime() && ts < next.getTime()
    }).length
    perDay.push({ day: d.toLocaleDateString("id-ID", { weekday: "short", day: "numeric" }), count })
  }

  return NextResponse.json({
    totalUsers: usersSnap.size,
    onlineUsers: onlineSnap.size,
    bannedUsers: bannedSnap.size,
    verifiedUsers: verifiedSnap.size,
    newUsersToday: newTodaySnap.size,
    totalMessages: msgsSnap.size,
    messagesToday: msgsTodaySnap.size,
    totalGroups: groupsSnap.size,
    totalChannels: channelsSnap.size,
    totalStories: storiesSnap.size,
    openReports: 0,
    totalCalls: callsSnap.size,
    messagesPerDay: perDay,
  })
}
