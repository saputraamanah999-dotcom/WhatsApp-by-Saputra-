// Channels API (Firebase)
import { NextResponse } from "next/server"
import { getAdminDb, ensureAdminSignedIn } from "@/lib/firebase-server"
import { getCurrentUid } from "@/lib/session"
import { slugify } from "@/lib/utils"

export async function GET(req: Request) {
  const uid = await getCurrentUid(req)
  if (!uid) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  await ensureAdminSignedIn()
  const adminDb = getAdminDb()
  if (!adminDb) return NextResponse.json({ error: "Firestore not configured" }, { status: 500 })

  const url = new URL(req.url)
  const q = url.searchParams.get("q")?.trim().toLowerCase() || ""
  const followed = url.searchParams.get("followed") === "1"

  if (followed) {
    const followsSnap = await adminDb
      .collection("channel_follows")
      .where("userId", "==", uid)
      .get()
    const channels: any[] = []
    for (const fdoc of followsSnap.docs) {
      const channelId = fdoc.data().channelId
      const channelDoc = await adminDb.collection("channels").doc(channelId).get()
      if (!channelDoc.exists) continue
      const c = channelDoc.data()!
      const ownerDoc = await adminDb.collection("users").doc(c.ownerId).get()
      const owner = ownerDoc.exists ? ownerDoc.data()! : null
      channels.push({
        id: channelDoc.id,
        name: c.name,
        slug: c.slug,
        description: c.description,
        photoURL: c.photoURL,
        ownerId: c.ownerId,
        owner: owner ? {
          username: owner.username,
          displayName: owner.displayName,
          photoURL: owner.photoURL,
          verified: owner.verified || false,
        } : null,
        visibility: c.visibility,
        followerCount: c.followerCount || 0,
        createdAt: c.createdAt,
      })
    }
    return NextResponse.json({ channels })
  }

  const snap = await adminDb.collection("channels").get()
  const channels: any[] = []
  for (const doc of snap.docs) {
    const d = doc.data()
    if (q && !d.name.toLowerCase().includes(q) && !d.slug.toLowerCase().includes(q)) continue
    const ownerDoc = await adminDb.collection("users").doc(d.ownerId).get()
    const owner = ownerDoc.exists ? ownerDoc.data()! : null
    channels.push({
      id: doc.id,
      name: d.name,
      slug: d.slug,
      description: d.description,
      photoURL: d.photoURL,
      ownerId: d.ownerId,
      owner: owner ? {
        username: owner.username,
        displayName: owner.displayName,
        photoURL: owner.photoURL,
        verified: owner.verified || false,
      } : null,
      visibility: d.visibility,
      followerCount: d.followerCount || 0,
      createdAt: d.createdAt,
    })
  }
  channels.sort((a, b) => b.followerCount - a.followerCount)
  return NextResponse.json({ channels: channels.slice(0, 50) })
}

export async function POST(req: Request) {
  const uid = await getCurrentUid(req)
  if (!uid) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const body = await req.json()
  const name = String(body.name || "").trim().slice(0, 50)
  const description = String(body.description || "").trim().slice(0, 500)
  let slug = slugify(body.slug || name)
  if (!slug) slug = "ch_" + Date.now().toString(36)

  if (!name) return NextResponse.json({ error: "Nama channel wajib diisi" }, { status: 400 })

  await ensureAdminSignedIn()
  const adminDb = getAdminDb()
  if (!adminDb) return NextResponse.json({ error: "Firestore not configured" }, { status: 500 })

  const existing = await adminDb.collection("channels").where("slug", "==", slug).get()
  if (!existing.empty) return NextResponse.json({ error: "Slug sudah dipakai" }, { status: 400 })

  const ref = await adminDb.collection("channels").add({
    name,
    slug,
    description,
    photoURL: null,
    ownerId: uid,
    visibility: "public",
    followerCount: 0,
    createdAt: Date.now(),
    updatedAt: Date.now(),
  })
  // Auto-follow own channel
  await adminDb.collection("channel_follows").add({
    channelId: ref.id,
    userId: uid,
    createdAt: Date.now(),
  })
  await ref.update({ followerCount: 1 })

  return NextResponse.json({
    channel: { id: ref.id, name, slug, description, ownerId: uid, followerCount: 1, createdAt: Date.now() },
  })
}
