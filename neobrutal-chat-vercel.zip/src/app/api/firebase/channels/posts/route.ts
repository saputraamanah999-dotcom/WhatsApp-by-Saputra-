// Channel posts API (Firebase)
import { NextResponse } from "next/server"
import { getAdminDb, ensureAdminSignedIn } from "@/lib/firebase-server"
import { getCurrentUid } from "@/lib/session"

export async function GET(req: Request) {
  const uid = await getCurrentUid(req)
  if (!uid) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const url = new URL(req.url)
  const channelId = url.searchParams.get("channelId")
  if (!channelId) return NextResponse.json({ error: "channelId required" }, { status: 400 })

  await ensureAdminSignedIn()
  const adminDb = getAdminDb()
  if (!adminDb) return NextResponse.json({ error: "Firestore not configured" }, { status: 500 })

  const snap = await adminDb
    .collection("channel_posts")
    .where("channelId", "==", channelId)
    .orderBy("createdAt", "desc")
    .limit(50)
    .get()

  const posts: any[] = []
  for (const doc of snap.docs) {
    const d = doc.data()
    const authorDoc = await adminDb.collection("users").doc(d.authorId).get()
    const author = authorDoc.exists ? authorDoc.data()! : null
    posts.push({
      id: doc.id,
      channelId: d.channelId,
      authorId: d.authorId,
      authorUsername: author?.username || "",
      authorDisplayName: author?.displayName || "",
      authorPhoto: author?.photoURL || null,
      authorVerified: author?.verified || false,
      text: d.text,
      mediaURL: d.mediaURL,
      mediaType: d.mediaType,
      pinned: d.pinned || false,
      viewCount: d.viewCount || 0,
      reactions: d.reactions || "{}",
      createdAt: d.createdAt,
    })
  }
  return NextResponse.json({ posts })
}

export async function POST(req: Request) {
  const uid = await getCurrentUid(req)
  if (!uid) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const body = await req.json()
  const channelId = body.channelId
  const text = String(body.text || "").trim().slice(0, 5000)
  const mediaURL = body.mediaURL || null
  const mediaType = body.mediaType || null

  if (!channelId) return NextResponse.json({ error: "channelId required" }, { status: 400 })
  if (!text && !mediaURL) return NextResponse.json({ error: "Empty" }, { status: 400 })

  await ensureAdminSignedIn()
  const adminDb = getAdminDb()
  if (!adminDb) return NextResponse.json({ error: "Firestore not configured" }, { status: 500 })

  const channelDoc = await adminDb.collection("channels").doc(channelId).get()
  if (!channelDoc.exists) return NextResponse.json({ error: "Channel tidak ditemukan" }, { status: 404 })
  if (channelDoc.data()!.ownerId !== uid) {
    return NextResponse.json({ error: "Hanya pemilik channel yang bisa memposting" }, { status: 403 })
  }

  const userDoc = await adminDb.collection("users").doc(uid).get()
  const user = userDoc.data()!
  const ref = await adminDb.collection("channel_posts").add({
    channelId,
    authorId: uid,
    text,
    mediaURL,
    mediaType,
    pinned: false,
    viewCount: 0,
    reactions: "{}",
    createdAt: Date.now(),
  })

  return NextResponse.json({
    post: {
      id: ref.id,
      channelId,
      authorId: uid,
      authorUsername: user.username,
      authorDisplayName: user.displayName,
      authorPhoto: user.photoURL,
      authorVerified: user.verified || false,
      text,
      mediaURL,
      mediaType,
      pinned: false,
      viewCount: 0,
      reactions: "{}",
      createdAt: Date.now(),
    },
  })
}
