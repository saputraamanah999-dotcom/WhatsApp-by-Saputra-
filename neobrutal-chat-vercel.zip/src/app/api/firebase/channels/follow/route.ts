// Channel follow API (Firebase)
import { NextResponse } from "next/server"
import { getAdminDb, ensureAdminSignedIn } from "@/lib/firebase-server"
import { getCurrentUid } from "@/lib/session"

export async function POST(req: Request) {
  const uid = await getCurrentUid(req)
  if (!uid) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const body = await req.json()
  const { channelId } = body as { channelId: string }
  if (!channelId) return NextResponse.json({ error: "channelId required" }, { status: 400 })

  await ensureAdminSignedIn()
  const adminDb = getAdminDb()
  if (!adminDb) return NextResponse.json({ error: "Firestore not configured" }, { status: 500 })

  const existing = await adminDb
    .collection("channel_follows")
    .where("channelId", "==", channelId)
    .where("userId", "==", uid)
    .get()
  if (!existing.empty) return NextResponse.json({ ok: true, following: true })

  await adminDb.collection("channel_follows").add({
    channelId,
    userId: uid,
    createdAt: Date.now(),
  })
  const channelDoc = await adminDb.collection("channels").doc(channelId).get()
  if (channelDoc.exists) {
    await adminDb.collection("channels").doc(channelId).update({
      followerCount: (channelDoc.data()!.followerCount || 0) + 1,
    })
  }
  return NextResponse.json({ ok: true, following: true })
}

export async function DELETE(req: Request) {
  const uid = await getCurrentUid(req)
  if (!uid) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  await ensureAdminSignedIn()
  const adminDb = getAdminDb()
  if (!adminDb) return NextResponse.json({ error: "Firestore not configured" }, { status: 500 })

  const url = new URL(req.url)
  const channelId = url.searchParams.get("channelId")
  if (!channelId) return NextResponse.json({ error: "channelId required" }, { status: 400 })

  const followsSnap = await adminDb
    .collection("channel_follows")
    .where("channelId", "==", channelId)
    .where("userId", "==", uid)
    .get()
  const batch = adminDb.batch()
  followsSnap.forEach((doc) => batch.delete(doc.ref))
  await batch.commit()

  const channelDoc = await adminDb.collection("channels").doc(channelId).get()
  if (channelDoc.exists) {
    await adminDb.collection("channels").doc(channelId).update({
      followerCount: Math.max(0, (channelDoc.data()!.followerCount || 1) - 1),
    })
  }
  return NextResponse.json({ ok: true, following: false })
}
