// Search API (Firebase) - search users, groups, channels
import { NextResponse } from "next/server"
import { getAdminDb, ensureAdminSignedIn } from "@/lib/firebase-server"
import { getCurrentUid } from "@/lib/session"

export async function GET(req: Request) {
  const uid = await getCurrentUid(req)
  if (!uid) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const url = new URL(req.url)
  const q = url.searchParams.get("q")?.trim().toLowerCase() || ""
  if (!q || q.length < 2) return NextResponse.json({ users: [], groups: [], channels: [] })

  await ensureAdminSignedIn()
  const adminDb = getAdminDb()
  if (!adminDb) return NextResponse.json({ error: "Firestore not configured" }, { status: 500 })

  // Users: filter client-side (Firestore doesn't support contains)
  const usersSnap = await adminDb.collection("users").where("banned", "==", false).get()
  const users = usersSnap.docs
    .filter((doc) => {
      const d = doc.data()
      if (doc.id === uid) return false
      return (d.username?.toLowerCase().includes(q)) || (d.displayName?.toLowerCase().includes(q))
    })
    .slice(0, 20)
    .map((doc) => {
      const d = doc.data()
      return {
        id: doc.id,
        username: d.username,
        displayName: d.displayName,
        photoURL: d.photoURL,
        verified: d.verified || false,
        online: d.online || false,
        lastSeen: d.lastSeen || 0,
        bio: d.bio,
      }
    })

  // Groups
  const groupsSnap = await adminDb.collection("groups").where("visibility", "==", "public").get()
  const groups = groupsSnap.docs
    .filter((doc) => {
      const d = doc.data()
      return d.name?.toLowerCase().includes(q) || d.description?.toLowerCase().includes(q)
    })
    .slice(0, 20)
    .map((doc) => ({ id: doc.id, ...doc.data() }))

  // Channels
  const channelsSnap = await adminDb.collection("channels").get()
  const channels = channelsSnap.docs
    .filter((doc) => {
      const d = doc.data()
      return d.name?.toLowerCase().includes(q) || d.slug?.toLowerCase().includes(q) || d.description?.toLowerCase().includes(q)
    })
    .slice(0, 20)
    .map((doc) => ({ id: doc.id, ...doc.data() }))

  return NextResponse.json({ users, groups, channels })
}
