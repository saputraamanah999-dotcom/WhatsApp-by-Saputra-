// Groups API (Firebase)
import { NextResponse } from "next/server"
import { getAdminDb, ensureAdminSignedIn } from "@/lib/firebase-server"
import { getCurrentUid } from "@/lib/session"
import { genInviteCode } from "@/lib/utils"

export async function GET(req: Request) {
  await ensureAdminSignedIn()
  const adminDb = getAdminDb()
  if (!adminDb) return NextResponse.json({ error: "Firestore not configured" }, { status: 500 })

  const url = new URL(req.url)
  const q = url.searchParams.get("q")?.trim().toLowerCase() || ""

  const snap = await adminDb.collection("groups").where("visibility", "==", "public").get()
  const groups: any[] = []
  for (const doc of snap.docs) {
    const d = doc.data()
    if (q && !d.name.toLowerCase().includes(q)) continue
    const ownerDoc = await adminDb.collection("users").doc(d.ownerId).get()
    const owner = ownerDoc.exists ? ownerDoc.data()! : null
    groups.push({
      id: doc.id,
      name: d.name,
      description: d.description,
      photoURL: d.photoURL,
      ownerId: d.ownerId,
      owner: owner ? {
        username: owner.username,
        displayName: owner.displayName,
        photoURL: owner.photoURL,
        verified: owner.verified || false,
      } : null,
      visibility: d.visibility,
      joinPolicy: d.joinPolicy,
      inviteCode: d.inviteCode,
      memberCount: d.memberCount || 0,
      createdAt: d.createdAt,
    })
  }
  groups.sort((a, b) => b.memberCount - a.memberCount)
  return NextResponse.json({ groups: groups.slice(0, 50) })
}

export async function POST(req: Request) {
  const uid = await getCurrentUid(req)
  if (!uid) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const body = await req.json()
  const name = String(body.name || "").trim().slice(0, 50)
  const description = String(body.description || "").trim().slice(0, 500)
  const visibility = body.visibility === "private" ? "private" : "public"
  const joinPolicy = body.joinPolicy === "approval" ? "approval" : "open"

  if (!name) return NextResponse.json({ error: "Nama grup wajib diisi" }, { status: 400 })

  await ensureAdminSignedIn()
  const adminDb = getAdminDb()
  if (!adminDb) return NextResponse.json({ error: "Firestore not configured" }, { status: 500 })

  const ref = await adminDb.collection("groups").add({
    name,
    description,
    photoURL: null,
    ownerId: uid,
    visibility,
    joinPolicy,
    inviteCode: genInviteCode(),
    memberCount: 1,
    createdAt: Date.now(),
    updatedAt: Date.now(),
  })
  await adminDb
    .collection("groups")
    .doc(ref.id)
    .collection("members")
    .doc(uid)
    .set({ role: "owner", joinedAt: Date.now() })

  return NextResponse.json({ group: { id: ref.id, name, ownerId: uid } })
}
