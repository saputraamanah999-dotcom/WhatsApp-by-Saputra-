// Group members API (Firebase)
import { NextResponse } from "next/server"
import { getAdminDb, ensureAdminSignedIn } from "@/lib/firebase-server"
import { getCurrentUid } from "@/lib/session"

export async function GET(req: Request) {
  const uid = await getCurrentUid(req)
  if (!uid) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const url = new URL(req.url)
  const groupId = url.searchParams.get("groupId")
  if (!groupId) return NextResponse.json({ error: "groupId required" }, { status: 400 })

  await ensureAdminSignedIn()
  const adminDb = getAdminDb()
  if (!adminDb) return NextResponse.json({ error: "Firestore not configured" }, { status: 500 })

  const snap = await adminDb.collection("groups").doc(groupId).collection("members").get()
  const members: any[] = []
  for (const doc of snap.docs) {
    const d = doc.data()
    const userDoc = await adminDb.collection("users").doc(doc.id).get()
    const user = userDoc.exists ? userDoc.data()! : null
    members.push({
      id: doc.id,
      groupId,
      userId: doc.id,
      role: d.role,
      joinedAt: d.joinedAt,
      user: user ? {
        id: userDoc.id,
        username: user.username,
        displayName: user.displayName,
        photoURL: user.photoURL,
        verified: user.verified || false,
        online: user.online || false,
        lastSeen: user.lastSeen || 0,
      } : null,
    })
  }
  return NextResponse.json({ members })
}

export async function POST(req: Request) {
  const uid = await getCurrentUid(req)
  if (!uid) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const body = await req.json()
  const { groupId, inviteCode } = body

  await ensureAdminSignedIn()
  const adminDb = getAdminDb()
  if (!adminDb) return NextResponse.json({ error: "Firestore not configured" }, { status: 500 })

  const groupDoc = await adminDb.collection("groups").doc(groupId).get()
  if (!groupDoc.exists) return NextResponse.json({ error: "Grup tidak ditemukan" }, { status: 404 })

  const groupData = groupDoc.data()!
  if (groupData.visibility === "private") {
    if (!inviteCode || inviteCode !== groupData.inviteCode) {
      return NextResponse.json({ error: "Kode undangan tidak valid" }, { status: 403 })
    }
  }

  const memberRef = adminDb.collection("groups").doc(groupId).collection("members").doc(uid)
  const existing = await memberRef.get()
  if (existing.exists) return NextResponse.json({ error: "Sudah bergabung" }, { status: 400 })

  await memberRef.set({ role: "member", joinedAt: Date.now() })
  await adminDb.collection("groups").doc(groupId).update({ memberCount: (groupData.memberCount || 0) + 1 })
  return NextResponse.json({ ok: true })
}

export async function DELETE(req: Request) {
  const uid = await getCurrentUid(req)
  if (!uid) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const url = new URL(req.url)
  const groupId = url.searchParams.get("groupId")
  if (!groupId) return NextResponse.json({ error: "groupId required" }, { status: 400 })

  await ensureAdminSignedIn()
  const adminDb = getAdminDb()
  if (!adminDb) return NextResponse.json({ error: "Firestore not configured" }, { status: 500 })

  const memberRef = adminDb.collection("groups").doc(groupId).collection("members").doc(uid)
  const existing = await memberRef.get()
  if (!existing.exists) return NextResponse.json({ error: "Bukan anggota" }, { status: 400 })

  const role = existing.data()!.role
  if (role === "owner") {
    await adminDb.collection("groups").doc(groupId).delete()
  } else {
    await memberRef.delete()
    const groupDoc = await adminDb.collection("groups").doc(groupId).get()
    if (groupDoc.exists) {
      await adminDb.collection("groups").doc(groupId).update({
        memberCount: Math.max(0, (groupDoc.data()!.memberCount || 1) - 1),
      })
    }
  }
  return NextResponse.json({ ok: true })
}
