// Group messages API (Firebase)
import { NextResponse } from "next/server"
import { getAdminDb, ensureAdminSignedIn } from "@/lib/firebase-server"
import { getCurrentUid } from "@/lib/session"
import { parseMentions } from "@/lib/utils"

export async function GET(req: Request) {
  const uid = await getCurrentUid(req)
  if (!uid) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const url = new URL(req.url)
  const groupId = url.searchParams.get("groupId")
  if (!groupId) return NextResponse.json({ error: "groupId required" }, { status: 400 })

  await ensureAdminSignedIn()
  const adminDb = getAdminDb()
  if (!adminDb) return NextResponse.json({ error: "Firestore not configured" }, { status: 500 })

  const snap = await adminDb
    .collection("group_messages")
    .where("groupId", "==", groupId)
    .orderBy("createdAt", "asc")
    .limit(200)
    .get()

  const messages: any[] = []
  for (const doc of snap.docs) {
    const d = doc.data()
    const senderDoc = await adminDb.collection("users").doc(d.senderId).get()
    const sender = senderDoc.exists ? senderDoc.data()! : null
    messages.push({
      id: doc.id,
      groupId: d.groupId,
      senderId: d.senderId,
      senderUsername: sender?.username || "",
      senderDisplayName: sender?.displayName || "",
      senderPhoto: sender?.photoURL || null,
      senderVerified: sender?.verified || false,
      text: d.text,
      type: d.type,
      mediaURL: d.mediaURL,
      reactions: d.reactions || "{}",
      replyToId: d.replyToId,
      createdAt: d.createdAt,
    })
  }
  return NextResponse.json({ messages })
}

export async function POST(req: Request) {
  const uid = await getCurrentUid(req)
  if (!uid) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const body = await req.json()
  const groupId = body.groupId
  const text = String(body.text || "").trim().slice(0, 5000)
  const type = body.type || "text"
  const mediaURL = body.mediaURL || null
  const replyToId = body.replyToId || null

  if (!groupId) return NextResponse.json({ error: "groupId required" }, { status: 400 })
  if (!text && !mediaURL) return NextResponse.json({ error: "Empty" }, { status: 400 })

  await ensureAdminSignedIn()
  const adminDb = getAdminDb()
  if (!adminDb) return NextResponse.json({ error: "Firestore not configured" }, { status: 500 })

  const memberDoc = await adminDb.collection("groups").doc(groupId).collection("members").doc(uid).get()
  if (!memberDoc.exists) return NextResponse.json({ error: "Bukan anggota grup" }, { status: 403 })

  const userDoc = await adminDb.collection("users").doc(uid).get()
  if (userDoc.data()?.banned) return NextResponse.json({ error: "Dibanned" }, { status: 403 })

  const username = userDoc.data()?.username || ""
  const mentions = parseMentions(text)
  const ref = await adminDb.collection("group_messages").add({
    groupId,
    senderId: uid,
    senderUsername: username,
    text,
    type,
    mediaURL,
    replyToId,
    reactions: "{}",
    createdAt: Date.now(),
  })

  return NextResponse.json({
    message: {
      id: ref.id,
      groupId,
      senderId: uid,
      senderUsername: username,
      text,
      type,
      mediaURL,
      createdAt: Date.now(),
      replyToId,
      mentions,
    },
  })
}
