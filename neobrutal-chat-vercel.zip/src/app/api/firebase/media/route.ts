// Media upload API (Firebase) - upload to Firebase Storage via Admin SDK
import { NextResponse } from "next/server"
import { getAdminStorageInstance } from "@/lib/firebase-server"
import { getCurrentUid } from "@/lib/session"

const ALLOWED = {
  image: ["image/jpeg", "image/png", "image/webp", "image/gif"],
  video: ["video/mp4", "video/webm"],
  audio: ["audio/mp3", "audio/webm", "audio/ogg", "audio/wav", "audio/mpeg"],
  document: ["application/pdf", "text/plain"],
}
const MAX_SIZE = 15 * 1024 * 1024 // 15MB

function detectKind(mime: string): "image" | "video" | "audio" | "document" | null {
  for (const [k, list] of Object.entries(ALLOWED)) {
    if (list.includes(mime)) return k as any
  }
  return null
}

export async function POST(req: Request) {
  const uid = await getCurrentUid(req)
  if (!uid) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const formData = await req.formData()
  const file = formData.get("file") as File | null
  if (!file) return NextResponse.json({ error: "File required" }, { status: 400 })

  if (file.size > MAX_SIZE) {
    return NextResponse.json({ error: "File terlalu besar (max 15MB)" }, { status: 400 })
  }

  const kind = detectKind(file.type)
  if (!kind) {
    return NextResponse.json({ error: "Tipe file tidak didukung: " + file.type }, { status: 400 })
  }

  const adminStorage = getAdminStorageInstance()
  if (!adminStorage) {
    // Fallback: save to public/uploads locally
    return saveLocal(file, kind, uid)
  }

  const ext = file.name.split(".").pop() || kind
  const filename = `${kind}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}.${ext}`
  const filePath = `uploads/${kind}/${filename}`

  try {
    const bucket = adminStorage.bucket()
    const buffer = Buffer.from(await file.arrayBuffer())
    const fileRef = bucket.file(filePath)
    await fileRef.save(buffer, {
      metadata: { contentType: file.type },
      public: true,
    })
    // Make public URL
    const publicUrl = `https://storage.googleapis.com/${bucket.name}/${filePath}`
    return NextResponse.json({
      url: publicUrl,
      type: file.type,
      size: file.size,
      kind,
    })
  } catch (e: any) {
    console.error("[media] Firebase Storage upload failed, falling back to local:", e.message)
    return saveLocal(file, kind, uid)
  }
}

async function saveLocal(file: File, kind: string, _uid: string) {
  const { writeFile, mkdir } = await import("fs/promises")
  const path = await import("path")
  const { randomUUID } = await import("crypto")
  const ext = file.name.split(".").pop() || kind
  const filename = `${kind}_${randomUUID()}.${ext}`
  const dir = path.join(process.cwd(), "public", "uploads", kind)
  await mkdir(dir, { recursive: true })
  const filepath = path.join(dir, filename)
  const buf = Buffer.from(await file.arrayBuffer())
  await writeFile(filepath, buf)
  return NextResponse.json({
    url: `/uploads/${kind}/${filename}`,
    type: file.type,
    size: file.size,
    kind,
    note: "Saved locally (Firebase Storage not configured)",
  })
}
