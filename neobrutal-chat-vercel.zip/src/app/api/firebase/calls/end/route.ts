import { NextResponse } from "next/server"
import { getAdminDb, ensureAdminSignedIn } from "@/lib/firebase-server"
import { getCurrentUid } from "@/lib/session"

export async function POST(req: Request) {
  const uid = await getCurrentUid(req)
  if (!uid) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const body = await req.json()
  const { callId, status, durationSeconds } = body

  if (!callId || !status) return NextResponse.json({ error: "missing" }, { status: 400 })

  await ensureAdminSignedIn()
  const adminDb = getAdminDb()
  if (!adminDb) return NextResponse.json({ error: "Firestore not configured" }, { status: 500 })

  const ref = adminDb.collection("calls").doc(callId)
  const doc = await ref.get()
  if (!doc.exists) return NextResponse.json({ error: "Not found" }, { status: 404 })
  if (doc.data()!.callerId !== uid && doc.data()!.calleeId !== uid) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 })
  }

  const data: any = { status }
  if (status === "active" && !doc.data()!.startedAt) data.startedAt = Date.now()
  if (["ended", "missed", "rejected", "failed"].includes(status)) {
    data.endedAt = Date.now()
    if (durationSeconds !== undefined) data.durationSeconds = durationSeconds
  }
  await ref.update(data)
  return NextResponse.json({ ok: true })
}
