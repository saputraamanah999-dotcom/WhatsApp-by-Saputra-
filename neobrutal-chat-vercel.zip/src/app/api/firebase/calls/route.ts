// Calls API (Firebase) - create call record
import { NextResponse } from "next/server"
import { getAdminDb, ensureAdminSignedIn } from "@/lib/firebase-server"
import { getCurrentUid } from "@/lib/session"

export async function GET() {
  const uid = await getCurrentUid()
  if (!uid) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  await ensureAdminSignedIn()
  const adminDb = getAdminDb()
  if (!adminDb) return NextResponse.json({ error: "Firestore not configured" }, { status: 500 })

  const callerSnap = await adminDb.collection("calls").where("callerId", "==", uid).orderBy("createdAt", "desc").limit(50).get()
  const calleeSnap = await adminDb.collection("calls").where("calleeId", "==", uid).orderBy("createdAt", "desc").limit(50).get()

  const allDocs = [...callerSnap.docs, ...calleeSnap.docs]
  const seen = new Set<string>()
  const calls: any[] = []
  for (const doc of allDocs) {
    if (seen.has(doc.id)) continue
    seen.add(doc.id)
    const d = doc.data()
    const callerDoc = await adminDb.collection("users").doc(d.callerId).get()
    const calleeDoc = await adminDb.collection("users").doc(d.calleeId).get()
    calls.push({
      id: doc.id,
      callerId: d.callerId,
      calleeId: d.calleeId,
      callType: d.callType,
      status: d.status,
      startedAt: d.startedAt,
      endedAt: d.endedAt,
      durationSeconds: d.durationSeconds,
      caller: callerDoc.exists ? {
        username: callerDoc.data()!.username,
        displayName: callerDoc.data()!.displayName,
        photoURL: callerDoc.data()!.photoURL,
      } : null,
      callee: calleeDoc.exists ? {
        username: calleeDoc.data()!.username,
        displayName: calleeDoc.data()!.displayName,
        photoURL: calleeDoc.data()!.photoURL,
      } : null,
      createdAt: d.createdAt,
    })
  }
  calls.sort((a, b) => b.createdAt - a.createdAt)
  return NextResponse.json({ calls })
}

export async function POST(req: Request) {
  const uid = await getCurrentUid(req)
  if (!uid) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const body = await req.json()
  const { calleeId, callType } = body as { calleeId: string; callType: string }
  if (!calleeId) return NextResponse.json({ error: "calleeId required" }, { status: 400 })

  await ensureAdminSignedIn()
  const adminDb = getAdminDb()
  if (!adminDb) return NextResponse.json({ error: "Firestore not configured" }, { status: 500 })

  const ref = await adminDb.collection("calls").add({
    callerId: uid,
    calleeId,
    callType: callType === "video" ? "video" : "voice",
    status: "ringing",
    createdAt: Date.now(),
  })

  return NextResponse.json({
    call: {
      id: ref.id,
      callerId: uid,
      calleeId,
      callType: callType === "video" ? "video" : "voice",
      status: "ringing",
      createdAt: Date.now(),
    },
  })
}
