// Direct Message API (Firebase)
import { NextResponse } from "next/server"
import { getAdminDb, ensureAdminSignedIn } from "@/lib/firebase-server"
import { getCurrentUid } from "@/lib/session"
import { chatIdOf, parseMentions } from "@/lib/utils"

export async function GET(req: Request) {
  const uid = await getCurrentUid(req)
  if (!uid) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  await ensureAdminSignedIn()
  const adminDb = getAdminDb()
  if (!adminDb) return NextResponse.json({ error: "Firestore not configured" }, { status: 500 })

  const url = new URL(req.url)
  const partnerId = url.searchParams.get("partnerId")

  if (partnerId) {
    const cid = chatIdOf(uid, partnerId)
    const snap = await adminDb
      .collection("dms")
      .where("chatId", "==", cid)
      .orderBy("createdAt", "asc")
      .limit(200)
      .get()
    const messages: any[] = []
    snap.forEach((doc) => {
      const d = doc.data()
      if (d.deletedAt) return
      messages.push({
        id: doc.id,
        chatId: d.chatId,
        senderId: d.senderId,
        receiverId: d.receiverId,
        text: d.text,
        type: d.type,
        mediaURL: d.mediaURL,
        replyToId: d.replyToId,
        status: d.status,
        reactions: d.reactions || "{}",
        createdAt: d.createdAt,
      })
    })
    return NextResponse.json({ messages })
  }

  // List chat partners with last message
  const sentSnap = await adminDb.collection("dms").where("senderId", "==", uid).get()
  const receivedSnap = await adminDb.collection("dms").where("receiverId", "==", uid).get()
  const partnerMap: Record<string, any> = {}
  sentSnap.forEach((doc) => {
    const d = doc.data()
    const pid = d.receiverId
    if (!partnerMap[pid] || d.createdAt > partnerMap[pid].createdAt) {
      partnerMap[pid] = {
        text: d.text,
        createdAt: d.createdAt,
        status: d.status,
        type: d.type,
        me: true,
      }
    }
  })
  receivedSnap.forEach((doc) => {
    const d = doc.data()
    const pid = d.senderId
    if (!partnerMap[pid] || d.createdAt > partnerMap[pid].createdAt) {
      partnerMap[pid] = {
        text: d.text,
        createdAt: d.createdAt,
        status: d.status,
        type: d.type,
        me: false,
      }
    }
  })

  // Unread counts
  const unreadSnap = await adminDb
    .collection("dms")
    .where("receiverId", "==", uid)
    .where("status", "!=", "read")
    .get()
  const unreadMap: Record<string, number> = {}
  unreadSnap.forEach((doc) => {
    const pid = doc.data().senderId
    unreadMap[pid] = (unreadMap[pid] || 0) + 1
  })

  const partnerIds = Object.keys(partnerMap)
  if (partnerIds.length === 0) return NextResponse.json({ chats: [] })
  const partnerDocs = await Promise.all(
    partnerIds.map((pid) => adminDb.collection("users").doc(pid).get())
  )
  const chats = partnerIds
    .map((pid, i) => {
      const doc = partnerDocs[i]
      if (!doc.exists) return null
      const u = doc.data()!
      return {
        partner: {
          id: doc.id,
          username: u.username,
          displayName: u.displayName,
          photoURL: u.photoURL,
          verified: u.verified || false,
          online: u.online || false,
          lastSeen: u.lastSeen || 0,
        },
        lastMessage: partnerMap[pid],
        unread: unreadMap[pid] || 0,
      }
    })
    .filter(Boolean)
    .sort((a, b) => b!.lastMessage.createdAt - a!.lastMessage.createdAt)

  return NextResponse.json({ chats })
}

// Save DM message
export async function POST(req: Request) {
  const uid = await getCurrentUid(req)
  if (!uid) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const body = await req.json()
  const receiverId = body.receiverId
  const text = String(body.text || "").trim().slice(0, 5000)
  const type = body.type || "text"
  const mediaURL = body.mediaURL || null
  const replyToId = body.replyToId || null

  if (!receiverId) return NextResponse.json({ error: "receiverId required" }, { status: 400 })
  if (!text && !mediaURL) return NextResponse.json({ error: "Empty message" }, { status: 400 })

  await ensureAdminSignedIn()
  const adminDb = getAdminDb()
  if (!adminDb) return NextResponse.json({ error: "Firestore not configured" }, { status: 500 })

  const receiverDoc = await adminDb.collection("users").doc(receiverId).get()
  if (!receiverDoc.exists) return NextResponse.json({ error: "Receiver not found" }, { status: 404 })

  const senderDoc = await adminDb.collection("users").doc(uid).get()
  const sender = senderDoc.data()!
  if (sender.banned) return NextResponse.json({ error: "Akun dibanned" }, { status: 403 })

  const chatId = chatIdOf(uid, receiverId)
  const status = receiverDoc.data()!.online ? "delivered" : "sent"
  const msgRef = await adminDb.collection("dms").add({
    chatId,
    senderId: uid,
    receiverId,
    text: text || "",
    type,
    mediaURL,
    replyToId,
    status,
    reactions: "{}",
    createdAt: Date.now(),
    senderUsername: sender.username,
  })

  const msgDoc = await msgRef.get()
  const d = msgDoc.data()!
  return NextResponse.json({
    message: {
      id: msgDoc.id,
      chatId: d.chatId,
      senderId: d.senderId,
      receiverId: d.receiverId,
      text: d.text,
      type: d.type,
      mediaURL: d.mediaURL,
      createdAt: d.createdAt,
      status: d.status,
      senderUsername: sender.username,
    },
  })
}

// Update status (read receipts)
export async function PATCH(req: Request) {
  const uid = await getCurrentUid(req)
  if (!uid) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const body = await req.json()
  const { chatId, status } = body as { chatId: string; status: string }
  if (!chatId || !status) return NextResponse.json({ error: "missing" }, { status: 400 })

  if (status === "read") {
    await ensureAdminSignedIn()
  const adminDb = getAdminDb()
    if (!adminDb) return NextResponse.json({ error: "Firestore not configured" }, { status: 500 })
    const snap = await adminDb
      .collection("dms")
      .where("chatId", "==", chatId)
      .where("receiverId", "==", uid)
      .where("status", "!=", "read")
      .get()
    const batch = adminDb.batch()
    snap.forEach((doc) => batch.update(doc.ref, { status: "read" }))
    await batch.commit()
  }
  return NextResponse.json({ ok: true })
}
