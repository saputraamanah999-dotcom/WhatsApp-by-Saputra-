import { NextResponse } from "next/server"
import { getAdminDb, ensureAdminSignedIn } from "@/lib/firebase-server"
import { getCurrentUid } from "@/lib/session"

export async function POST(req: Request) {
  const uid = await getCurrentUid(req)
  if (!uid) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const body = await req.json()
  const { messageId, emoji } = body as { messageId: string; emoji: string }
  if (!messageId || !emoji) return NextResponse.json({ error: "missing" }, { status: 400 })

  await ensureAdminSignedIn()
  const adminDb = getAdminDb()
  if (!adminDb) return NextResponse.json({ error: "Firestore not configured" }, { status: 500 })

  const ref = adminDb.collection("dms").doc(messageId)
  const doc = await ref.get()
  if (!doc.exists) return NextResponse.json({ error: "Not found" }, { status: 404 })

  const reactions: Record<string, string[]> = (() => {
    try { return JSON.parse(doc.data()!.reactions || "{}") } catch { return {} }
  })()
  const list: string[] = reactions[emoji] || []
  const idx = list.indexOf(uid)
  if (idx >= 0) list.splice(idx, 1)
  else list.push(uid)
  if (list.length) reactions[emoji] = list
  else delete reactions[emoji]

  await ref.update({ reactions: JSON.stringify(reactions) })
  return NextResponse.json({ emoji, userIds: list })
}
