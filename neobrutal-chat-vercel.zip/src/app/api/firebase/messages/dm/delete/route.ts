import { NextResponse } from "next/server"
import { getAdminDb, ensureAdminSignedIn } from "@/lib/firebase-server"
import { getCurrentUid } from "@/lib/session"

export async function POST(req: Request) {
  const uid = await getCurrentUid(req)
  if (!uid) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const body = await req.json()
  const { messageId } = body as { messageId: string }
  if (!messageId) return NextResponse.json({ error: "missing" }, { status: 400 })

  await ensureAdminSignedIn()
  const adminDb = getAdminDb()
  if (!adminDb) return NextResponse.json({ error: "Firestore not configured" }, { status: 500 })

  const ref = adminDb.collection("dms").doc(messageId)
  const doc = await ref.get()
  if (!doc.exists) return NextResponse.json({ error: "Not found" }, { status: 404 })

  if (doc.data()!.senderId !== uid) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 })
  }
  await ref.update({ text: "", type: "system", deletedAt: Date.now() })
  return NextResponse.json({ ok: true })
}
