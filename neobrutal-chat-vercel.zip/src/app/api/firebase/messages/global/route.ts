// Global Chat API (Firebase)
import { NextResponse } from "next/server"
import { getAdminDb, ensureAdminSignedIn } from "@/lib/firebase-server"
import { getCurrentUid } from "@/lib/session"
import { parseMentions } from "@/lib/utils"

export async function GET() {
  await ensureAdminSignedIn()
  const adminDb = getAdminDb()
  if (!adminDb) return NextResponse.json({ error: "Firestore not configured" }, { status: 500 })

  const snap = await adminDb
    .collection("global")
    .orderBy("createdAt", "asc")
    .limitToLast(200)
    .get()

  const messages: any[] = []
  for (const doc of snap.docs) {
    const d = doc.data()
    const senderDoc = await adminDb.collection("users").doc(d.senderId).get()
    const sender = senderDoc.exists ? senderDoc.data()! : null
    messages.push({
      id: doc.id,
      senderId: d.senderId,
      senderUsername: sender?.username || "",
      senderDisplayName: sender?.displayName || "",
      senderPhoto: sender?.photoURL || null,
      senderVerified: sender?.verified || false,
      text: d.text,
      type: d.type,
      mediaURL: d.mediaURL,
      reactions: d.reactions || "{}",
      pinned: d.pinned || false,
      replyToId: d.replyToId,
      createdAt: d.createdAt,
    })
  }
  return NextResponse.json({ messages })
}

export async function POST(req: Request) {
  const uid = await getCurrentUid(req)
  if (!uid) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const body = await req.json()
  const text = String(body.text || "").trim().slice(0, 5000)
  if (!text) return NextResponse.json({ error: "Pesan kosong" }, { status: 400 })

  await ensureAdminSignedIn()
  const adminDb = getAdminDb()
  if (!adminDb) return NextResponse.json({ error: "Firestore not configured" }, { status: 500 })

  // Rate limit: max 5 messages per 3 seconds
  const recentSnap = await adminDb
    .collection("global")
    .where("senderId", "==", uid)
    .where("createdAt", ">", Date.now() - 3000)
    .get()
  if (recentSnap.size >= 5) {
    return NextResponse.json({ error: "Slow mode: tunggu sebentar sebelum kirim lagi." }, { status: 429 })
  }

  const userDoc = await adminDb.collection("users").doc(uid).get()
  if (userDoc.data()?.banned) {
    return NextResponse.json({ error: "Akun dibanned" }, { status: 403 })
  }
  const username = userDoc.data()?.username || ""

  const mentions = parseMentions(text)
  const msgRef = await adminDb.collection("global").add({
    senderId: uid,
    senderUsername: username,
    text,
    type: body.type || "text",
    mediaURL: body.mediaURL || null,
    replyToId: body.replyToId || null,
    reactions: "{}",
    pinned: false,
    createdAt: Date.now(),
  })

  // Send mention notifications
  for (const uname of mentions) {
    const unameDoc = await adminDb.collection("usernames").doc(uname).get()
    if (unameDoc.exists) {
      const targetUid = unameDoc.data()!.uid
      if (targetUid !== uid) {
        await adminDb.collection("notifications").add({
          recipientId: targetUid,
          actorId: uid,
          actorUsername: username,
          type: "mention",
          targetType: "global",
          text: `${username} menyebutmu di Chat Global`,
          read: false,
          createdAt: Date.now(),
        })
      }
    }
  }

  return NextResponse.json({
    message: {
      id: msgRef.id,
      senderId: uid,
      senderUsername: username,
      text,
      type: body.type || "text",
      mediaURL: body.mediaURL || null,
      createdAt: Date.now(),
      replyToId: body.replyToId || null,
      mentions,
    },
  })
}

export async function PATCH(req: Request) {
  const uid = await getCurrentUid(req)
  if (!uid) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const body = await req.json()
  const { messageId, emoji } = body as { messageId: string; emoji: string }
  if (!messageId || !emoji) return NextResponse.json({ error: "missing" }, { status: 400 })

  await ensureAdminSignedIn()
  const adminDb = getAdminDb()
  if (!adminDb) return NextResponse.json({ error: "Firestore not configured" }, { status: 500 })

  const ref = adminDb.collection("global").doc(messageId)
  const doc = await ref.get()
  if (!doc.exists) return NextResponse.json({ error: "Not found" }, { status: 404 })

  const reactions: Record<string, string[]> = (() => {
    try { return JSON.parse(doc.data()!.reactions || "{}") } catch { return {} }
  })()
  const list: string[] = reactions[emoji] || []
  const idx = list.indexOf(uid)
  if (idx >= 0) list.splice(idx, 1)
  else list.push(uid)
  if (list.length) reactions[emoji] = list
  else delete reactions[emoji]

  await ref.update({ reactions: JSON.stringify(reactions) })
  return NextResponse.json({ emoji, userIds: list })
}

export async function DELETE(req: Request) {
  const uid = await getCurrentUid(req)
  if (!uid) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  await ensureAdminSignedIn()
  const adminDb = getAdminDb()
  if (!adminDb) return NextResponse.json({ error: "Firestore not configured" }, { status: 500 })

  const url = new URL(req.url)
  const messageId = url.searchParams.get("id")
  if (!messageId) return NextResponse.json({ error: "id required" }, { status: 400 })

  const ref = adminDb.collection("global").doc(messageId)
  const doc = await ref.get()
  if (!doc.exists) return NextResponse.json({ error: "Not found" }, { status: 404 })

  const userDoc = await adminDb.collection("users").doc(uid).get()
  const role = userDoc.data()?.role
  if (doc.data()!.senderId !== uid && role !== "admin" && role !== "superadmin") {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 })
  }
  await ref.delete()
  return NextResponse.json({ ok: true })
}
