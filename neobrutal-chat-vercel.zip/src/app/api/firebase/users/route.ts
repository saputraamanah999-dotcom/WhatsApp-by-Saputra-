// Users API (Firebase): get list, search, get mine, update profile
import { NextResponse } from "next/server"
import { getAdminDb, ensureAdminSignedIn } from "@/lib/firebase-server"
import { getCurrentUid } from "@/lib/session"
import { normalizeUsername } from "@/lib/utils"

export async function GET(req: Request) {
  const uid = await getCurrentUid(req)
  if (!uid) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  await ensureAdminSignedIn()
  const adminDb = getAdminDb()
  if (!adminDb) return NextResponse.json({ error: "Firestore not configured" }, { status: 500 })

  const url = new URL(req.url)
  const q = url.searchParams.get("q")?.trim().toLowerCase() || ""
  const mine = url.searchParams.get("mine") === "1"

  if (mine) {
    const doc = await adminDb.collection("users").doc(uid).get()
    if (!doc.exists) return NextResponse.json({ user: null })
    const d = doc.data()!
    return NextResponse.json({
      user: {
        id: doc.id,
        email: d.email,
        username: d.username,
        displayName: d.displayName,
        bio: d.bio,
        photoURL: d.photoURL,
        verified: d.verified || false,
        role: d.role || "user",
        banned: d.banned || false,
        online: d.online || false,
        lastSeen: d.lastSeen || 0,
        createdAt: d.createdAt || 0,
      },
    })
  }

  if (q) {
    // Firestore doesn't support case-insensitive contains natively, so we fetch and filter
    const snap = await adminDb.collection("users").where("banned", "==", false).get()
    const users: any[] = []
    snap.forEach((doc) => {
      const d = doc.data()
      if (
        (d.username && d.username.toLowerCase().includes(q)) ||
        (d.displayName && d.displayName.toLowerCase().includes(q))
      ) {
        users.push({
          id: doc.id,
          username: d.username,
          displayName: d.displayName,
          photoURL: d.photoURL,
          verified: d.verified || false,
          online: d.online || false,
          lastSeen: d.lastSeen || 0,
          bio: d.bio,
        })
      }
    })
    return NextResponse.json({ users: users.slice(0, 30) })
  }

  // List all (limit 50)
  const snap = await adminDb
    .collection("users")
    .where("banned", "==", false)
    .orderBy("online", "desc")
    .limit(50)
    .get()
  const users: any[] = []
  snap.forEach((doc) => {
    const d = doc.data()
    if (doc.id === uid) return
    users.push({
      id: doc.id,
      username: d.username,
      displayName: d.displayName,
      photoURL: d.photoURL,
      verified: d.verified || false,
      online: d.online || false,
      lastSeen: d.lastSeen || 0,
    })
  })
  return NextResponse.json({ users })
}

export async function PATCH(req: Request) {
  const uid = await getCurrentUid(req)
  if (!uid) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const body = await req.json()
  await ensureAdminSignedIn()
  const adminDb = getAdminDb()
  if (!adminDb) return NextResponse.json({ error: "Firestore not configured" }, { status: 500 })

  const data: any = { updatedAt: Date.now() }
  if (typeof body.displayName === "string" && body.displayName.length <= 30) {
    data.displayName = body.displayName.trim()
  }
  if (typeof body.bio === "string" && body.bio.length <= 160) {
    data.bio = body.bio.trim()
  }
  if (typeof body.photoURL === "string") {
    data.photoURL = body.photoURL
  }
  if (typeof body.username === "string") {
    const newUname = normalizeUsername(body.username)
    if (!/^[a-z0-9_]{3,20}$/.test(newUname)) {
      return NextResponse.json({ error: "Username tidak valid (3-20 karakter, huruf kecil, angka, _)" }, { status: 400 })
    }
    const existing = await adminDb.collection("usernames").doc(newUname).get()
    if (existing.exists && existing.data()?.uid !== uid) {
      return NextResponse.json({ error: "Username sudah dipakai" }, { status: 400 })
    }
    // Update username doc
    const oldUserDoc = await adminDb.collection("users").doc(uid).get()
    const oldUsername = oldUserDoc.data()?.username
    if (oldUsername && oldUsername !== newUname) {
      await adminDb.collection("usernames").doc(oldUsername).delete()
    }
    await adminDb.collection("usernames").doc(newUname).set({ uid, createdAt: Date.now() })
    data.username = newUname
  }

  await adminDb.collection("users").doc(uid).update(data)
  return NextResponse.json({ ok: true })
}
