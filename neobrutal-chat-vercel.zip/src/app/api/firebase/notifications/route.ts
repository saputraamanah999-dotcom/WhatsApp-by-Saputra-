// Notifications API (Firebase)
import { NextResponse } from "next/server"
import { getAdminDb, ensureAdminSignedIn } from "@/lib/firebase-server"
import { getCurrentUid } from "@/lib/session"

export async function GET() {
  const uid = await getCurrentUid()
  if (!uid) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  await ensureAdminSignedIn()
  const adminDb = getAdminDb()
  if (!adminDb) return NextResponse.json({ error: "Firestore not configured" }, { status: 500 })

  const snap = await adminDb
    .collection("notifications")
    .where("recipientId", "==", uid)
    .orderBy("createdAt", "desc")
    .limit(50)
    .get()

  const notifications = snap.docs.map((doc) => ({
    id: doc.id,
    ...doc.data(),
  }))
  return NextResponse.json({ notifications })
}

export async function PATCH(req: Request) {
  const uid = await getCurrentUid(req)
  if (!uid) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  await ensureAdminSignedIn()
  const adminDb = getAdminDb()
  if (!adminDb) return NextResponse.json({ error: "Firestore not configured" }, { status: 500 })

  const body = await req.json()
  const { all } = body as { all?: boolean }

  if (all) {
    const snap = await adminDb
      .collection("notifications")
      .where("recipientId", "==", uid)
      .where("read", "==", false)
      .get()
    const batch = adminDb.batch()
    snap.forEach((doc) => batch.update(doc.ref, { read: true }))
    await batch.commit()
    return NextResponse.json({ ok: true })
  }

  const { id } = body
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 })
  await adminDb.collection("notifications").doc(id).update({ read: true })
  return NextResponse.json({ ok: true })
}
