import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import { authOptions } from "@/lib/auth"
import { getServerSession } from "next-auth"
import { chatIdOf, parseMentions } from "@/lib/utils"

export async function GET(req: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const msgs = await db.globalMessage.findMany({
    orderBy: { createdAt: "asc" },
    take: 200,
    include: { sender: { select: { username: true, displayName: true, photoURL: true, verified: true } } },
  })
  // Last 200 messages — strip out sender relation
  const out = msgs.map((m) => ({
    id: m.id,
    senderId: m.senderId,
    senderUsername: m.sender?.username || "",
    senderDisplayName: m.sender?.displayName || "",
    senderPhoto: m.sender?.photoURL || null,
    senderVerified: m.sender?.verified || false,
    text: m.text,
    type: m.type,
    mediaURL: m.mediaURL,
    reactions: m.reactions,
    pinned: m.pinned,
    createdAt: m.createdAt,
    replyToId: m.replyToId,
  }))
  return NextResponse.json({ messages: out })
}

export async function POST(req: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const uid = (session.user as any).id

  const body = await req.json()
  const text = String(body.text || "").trim().slice(0, 5000)
  if (!text) return NextResponse.json({ error: "Pesan kosong" }, { status: 400 })

  // Rate limit: max 5 messages / 3 seconds
  const recent = await db.globalMessage.count({
    where: { senderId: uid, createdAt: { gt: new Date(Date.now() - 3000) } },
  })
  if (recent >= 5) {
    return NextResponse.json({ error: "Slow mode: tunggu sebentar sebelum kirim lagi." }, { status: 429 })
  }

  const user = await db.user.findUnique({ where: { id: uid }, select: { username: true, banned: true } })
  if (user?.banned) return NextResponse.json({ error: "Akun dibanned" }, { status: 403 })

  const mentions = parseMentions(text)
  const msg = await db.globalMessage.create({
    data: {
      senderId: uid,
      text,
      type: body.type || "text",
      mediaURL: body.mediaURL || null,
      replyToId: body.replyToId || null,
      reactions: "{}",
    },
  })

  return NextResponse.json({
    message: {
      id: msg.id,
      senderId: uid,
      senderUsername: user?.username || "",
      text: msg.text,
      type: msg.type,
      mediaURL: msg.mediaURL,
      createdAt: msg.createdAt,
      replyToId: msg.replyToId,
      mentions,
    },
  })
}

export async function PATCH(req: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const uid = (session.user as any).id

  const body = await req.json()
  const { messageId, emoji } = body as { messageId: string; emoji: string }

  const msg = await db.globalMessage.findUnique({ where: { id: messageId } })
  if (!msg) return NextResponse.json({ error: "Not found" }, { status: 404 })

  const reactions = JSON.parse(msg.reactions || "{}")
  const list: string[] = reactions[emoji] || []
  const idx = list.indexOf(uid)
  if (idx >= 0) list.splice(idx, 1)
  else list.push(uid)
  if (list.length) reactions[emoji] = list
  else delete reactions[emoji]

  await db.globalMessage.update({ where: { id: messageId }, data: { reactions: JSON.stringify(reactions) } })
  return NextResponse.json({ reactions, userIds: list })
}

export async function DELETE(req: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const uid = (session.user as any).id
  const user = await db.user.findUnique({ where: { id: uid }, select: { role: true } })

  const url = new URL(req.url)
  const messageId = url.searchParams.get("id")
  if (!messageId) return NextResponse.json({ error: "id required" }, { status: 400 })

  const msg = await db.globalMessage.findUnique({ where: { id: messageId } })
  if (!msg) return NextResponse.json({ error: "Not found" }, { status: 404 })

  if (msg.senderId !== uid && user?.role !== "admin" && user?.role !== "superadmin") {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 })
  }

  await db.globalMessage.delete({ where: { id: messageId } })
  return NextResponse.json({ ok: true })
}
