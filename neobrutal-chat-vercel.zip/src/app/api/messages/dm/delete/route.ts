import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import { authOptions } from "@/lib/auth"
import { getServerSession } from "next-auth"

export async function POST(req: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const uid = (session.user as any).id

  const body = await req.json()
  const { messageId, forEveryone } = body as { messageId: string; forEveryone?: boolean }

  const msg = await db.message.findUnique({ where: { id: messageId } })
  if (!msg) return NextResponse.json({ error: "Not found" }, { status: 404 })

  if (msg.senderId !== uid) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 })
  }

  if (forEveryone) {
    await db.message.update({ where: { id: messageId }, data: { deletedAt: new Date(), text: "" } })
  } else {
    // Soft delete only for this user (sender); for simplicity, mark deleted
    await db.message.update({ where: { id: messageId }, data: { deletedAt: new Date(), text: "" } })
  }
  return NextResponse.json({ ok: true })
}
