import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import { authOptions } from "@/lib/auth"
import { getServerSession } from "next-auth"
import { chatIdOf, parseReactions, stringifyReactions } from "@/lib/utils"

// Save DM message to DB (called from client after socket emits)
export async function POST(req: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const uid = (session.user as any).id

  const body = await req.json()
  const receiverId = body.receiverId
  const text = String(body.text || "").trim().slice(0, 5000)
  const type = body.type || "text"
  const mediaURL = body.mediaURL || null
  const replyToId = body.replyToId || null

  if (!receiverId) return NextResponse.json({ error: "receiverId required" }, { status: 400 })
  if (!text && !mediaURL) return NextResponse.json({ error: "Empty message" }, { status: 400 })

  const receiver = await db.user.findUnique({ where: { id: receiverId } })
  if (!receiver) return NextResponse.json({ error: "Receiver not found" }, { status: 404 })

  const user = await db.user.findUnique({ where: { id: uid }, select: { banned: true, username: true } })
  if (user?.banned) return NextResponse.json({ error: "Akun dibanned" }, { status: 403 })

  const chatId = chatIdOf(uid, receiverId)
  const msg = await db.message.create({
    data: {
      chatId,
      senderId: uid,
      receiverId,
      text: text || "",
      type,
      mediaURL,
      replyToId,
      status: receiver.online ? "delivered" : "sent",
      reactions: "{}",
    },
  })

  return NextResponse.json({
    message: {
      id: msg.id,
      chatId: msg.chatId,
      senderId: msg.senderId,
      receiverId: msg.receiverId,
      text: msg.text,
      type: msg.type,
      mediaURL: msg.mediaURL,
      createdAt: msg.createdAt,
      status: msg.status,
      senderUsername: user?.username,
    },
  })
}

// Update status (read receipts)
export async function PATCH(req: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const uid = (session.user as any).id

  const body = await req.json()
  const { chatId, status } = body as { chatId: string; status: string }
  if (!chatId || !status) return NextResponse.json({ error: "missing" }, { status: 400 })

  if (status === "read") {
    // Mark all messages in this chat addressed to me as read
    await db.message.updateMany({
      where: { chatId, receiverId: uid, status: { not: "read" } },
      data: { status: "read" },
    })
  }
  return NextResponse.json({ ok: true })
}
