import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import { authOptions } from "@/lib/auth"
import { getServerSession } from "next-auth"
import { chatIdOf } from "@/lib/utils"

export async function GET(req: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const uid = (session.user as any).id

  const url = new URL(req.url)
  const partnerId = url.searchParams.get("partnerId")

  if (partnerId) {
    const chatId = chatIdOf(uid, partnerId)
    const msgs = await db.message.findMany({
      where: { chatId, deletedAt: null },
      orderBy: { createdAt: "asc" },
      take: 200,
    })
    return NextResponse.json({ messages: msgs })
  }

  // List all DM chat partners with last message
  const sentMsgs = await db.message.findMany({
    where: { senderId: uid },
    select: { receiverId: true, text: true, createdAt: true, status: true, type: true },
    orderBy: { createdAt: "desc" },
    take: 500,
  })
  const receivedMsgs = await db.message.findMany({
    where: { receiverId: uid },
    select: { senderId: true, text: true, createdAt: true, status: true, type: true },
    orderBy: { createdAt: "desc" },
    take: 500,
  })
  const partnerMap: Record<string, { text: string; createdAt: any; status: string; type: string; me: boolean }> = {}
  for (const m of sentMsgs) {
    if (!partnerMap[m.receiverId] || new Date(m.createdAt) > new Date(partnerMap[m.receiverId].createdAt)) {
      partnerMap[m.receiverId] = { text: m.text, createdAt: m.createdAt, status: m.status, type: m.type, me: true }
    }
  }
  for (const m of receivedMsgs) {
    if (!partnerMap[m.senderId] || new Date(m.createdAt) > new Date(partnerMap[m.senderId].createdAt)) {
      partnerMap[m.senderId] = { text: m.text, createdAt: m.createdAt, status: m.status, type: m.type, me: false }
    }
  }
  const unread = await db.message.groupBy({
    by: ["senderId"],
    where: { receiverId: uid, status: { not: "read" } },
    _count: { _all: true },
  })
  const unreadMap: Record<string, number> = {}
  for (const u of unread) unreadMap[u.senderId] = u._count._all

  const partnerIds = Object.keys(partnerMap)
  const partners = await db.user.findMany({
    where: { id: { in: partnerIds } },
    select: { id: true, username: true, displayName: true, photoURL: true, verified: true, online: true, lastSeen: true },
  })
  const chats = partnerIds
    .map((pid) => {
      const p = partners.find((x) => x.id === pid)
      const last = partnerMap[pid]
      return p ? { partner: p, lastMessage: last, unread: unreadMap[pid] || 0 } : null
    })
    .filter(Boolean)
    .sort((a: any, b: any) => new Date(b.lastMessage.createdAt).getTime() - new Date(a.lastMessage.createdAt).getTime())

  return NextResponse.json({ chats })
}
