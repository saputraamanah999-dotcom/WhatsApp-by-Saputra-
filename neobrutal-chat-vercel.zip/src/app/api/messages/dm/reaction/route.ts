import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import { authOptions } from "@/lib/auth"
import { getServerSession } from "next-auth"
import { parseReactions, stringifyReactions } from "@/lib/utils"

export async function POST(req: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const uid = (session.user as any).id

  const body = await req.json()
  const { messageId, emoji } = body as { messageId: string; emoji: string }
  if (!messageId || !emoji) return NextResponse.json({ error: "missing" }, { status: 400 })

  const msg = await db.message.findUnique({ where: { id: messageId } })
  if (!msg) return NextResponse.json({ error: "Not found" }, { status: 404 })

  const reactions = parseReactions(msg.reactions)
  const list: string[] = reactions[emoji] || []
  const idx = list.indexOf(uid)
  if (idx >= 0) list.splice(idx, 1)
  else list.push(uid)
  if (list.length) reactions[emoji] = list
  else delete reactions[emoji]

  await db.message.update({ where: { id: messageId }, data: { reactions: stringifyReactions(reactions) } })
  return NextResponse.json({ emoji, userIds: list })
}
