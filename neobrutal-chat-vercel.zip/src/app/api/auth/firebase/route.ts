// Auth API: login (set HTTP-only cookie with ID token) + verify session
// NOTE: Registration is done directly from client via Firebase Client SDK
// (because Admin SDK requires service account which may not be configured)
import { NextResponse } from "next/server"
import { SESSION_COOKIE } from "@/lib/session"
import {
  getAdminAuthInstance,
  verifyIdToken,
} from "@/lib/firebase-server"

// Verify session: GET /api/auth/firebase
export async function GET(req: Request) {
  const authHeader = req.headers.get("authorization")
  if (!authHeader?.startsWith("Bearer ")) {
    return NextResponse.json({ user: null })
  }
  const token = authHeader.slice(7)
  const uid = await verifyIdToken(token)
  if (!uid) return NextResponse.json({ user: null }, { status: 401 })
  // We don't fetch user data here (client-side does that via Firestore)
  return NextResponse.json({ user: { uid } })
}

// Login: receive ID token, set HTTP-only cookie
export async function POST(req: Request) {
  const body = await req.json()
  const { action, idToken } = body as { action: string; idToken: string }

  if (action === "login") {
    if (!idToken) return NextResponse.json({ error: "idToken required" }, { status: 400 })
    const uid = await verifyIdToken(idToken)
    if (!uid) return NextResponse.json({ error: "Token tidak valid" }, { status: 401 })

    // If Admin SDK is available, check ban status
    const adminAuth = getAdminAuthInstance()
    if (adminAuth) {
      try {
        // We could fetch user data and check banned status, but Firestore writes
        // are done from client side, so just trust the token here
      } catch (e) {
        // ignore
      }
    }

    const res = NextResponse.json({ ok: true, uid })
    res.cookies.set(SESSION_COOKIE, idToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 60 * 60,
      path: "/",
    })
    return res
  }

  return NextResponse.json({ error: "Invalid action" }, { status: 400 })
}

// Logout: clear cookie
export async function DELETE() {
  const res = NextResponse.json({ ok: true })
  res.cookies.delete(SESSION_COOKIE)
  return res
}
