"use client"

import { useAuth } from "@/components/providers"
import { AuthScreen } from "@/components/auth/auth-screen"
import { AppShell } from "@/components/chat/app-shell"

export default function Home() {
  const { user, loading } = useAuth()

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center nb-dot-pattern">
        <div className="nb-card-lg p-8 flex flex-col items-center gap-3">
          <div className="w-16 h-16 rounded-full nb-pulse" style={{ background: "var(--color-nb-pink)", border: "3px solid var(--border)" }} />
          <div className="text-sm text-muted-foreground">Memuat Neobrutal Chat…</div>
        </div>
      </div>
    )
  }

  if (!user) {
    return <AuthScreen />
  }

  return <AppShell />
}
