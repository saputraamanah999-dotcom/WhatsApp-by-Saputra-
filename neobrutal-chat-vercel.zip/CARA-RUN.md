# 🚀 Cara Run Neobrutal Chat (Firebase Edition)

Panduan langkah demi langkah. Ikuti urutan ini.

---

## 📋 Yang Anda Butuhkan

Sebelum mulai, pastikan sudah install:
- **Node.js** v18+ atau **Bun** v1+ (recommended, lebih cepat)
- **Git** (untuk extract ZIP)
- **Browser** modern (Chrome/Firefox/Safari)

Download & install Bun dari: https://bun.sh/
```bash
# Windows (PowerShell)
powershell -c "irm bun.sh/install.ps1 | iex"

# Mac/Linux
curl -fsSL https://bun.sh/install | bash
```

---

## 📦 Step 1: Extract ZIP

```bash
# Extract ZIP ke folder
unzip neobrutal-chat-firebase.zip -d neobrutal-chat
cd neobrutal-chat
```

Kalau di Windows: klik kanan ZIP → Extract All → pilih folder.

---

## 📥 Step 2: Install Dependencies

```bash
bun install
```

Atau kalau pakai npm:
```bash
npm install
```

Tunggu sampai selesai (± 1-2 menit).

---

## 🔥 Step 3: Setup Firebase Console

Ini penting! Tanpa setup ini, aplikasi tidak akan bisa simpan data.

### 3a. Aktifkan Firestore Database

1. Buka https://console.firebase.google.com/
2. Login dengan Google account Anda
3. Pilih project: **projekwhattsaf**
4. Di sidebar kiri, klik **Firestore Database**
5. Klik **Create database**
6. Pilih **Production mode** → Next
7. Pilih region: **asia-southeast1** (Singapore) → Enable

### 3b. Setup Firestore Security Rules

1. Di Firestore Database, klik tab **Rules** (di atas)
2. Hapus semua isi yang ada
3. Copy paste semua isi file `firestore.rules` (ada di root project)
4. Klik **Publish** tombol di atas

### 3c. Aktifkan Email/Password Authentication

1. Di sidebar Firebase Console, klik **Authentication**
2. Klik **Get started**
3. Tab **Sign-in method**
4. Klik **Email/Password**
5. Toggle **Enable** → **Save**

### 3d. Aktifkan Firebase Storage

1. Di sidebar Firebase Console, klik **Storage**
2. Klik **Get started** → Next → Done
3. Klik tab **Rules**
4. Copy paste isi file `storage.rules` → **Publish**

---

## 🔑 Step 4: Dapatkan Service Account (PENTING!)

Service account diperlukan supaya server Next.js bisa baca/tulis data ke Firestore Anda.

### 4a. Download Service Account JSON

1. Di Firebase Console, klik **gear icon ⚙️** (Project Settings) di samping "Project Overview"
2. Klik tab **Service accounts**
3. Scroll ke bawah, klik tombol **Generate new private key**
4. Klik **Generate key** (popup konfirmasi)
5. File JSON akan ter-download otomatis (nama seperti `projekwhattsaf-firebase-adminsdk-xxxxx.json`)

### 4b. Taruh File di Root Project

Rename file yang sudah ter-download jadi `service-account.json` dan taruh di **root folder project** (sejajar dengan `package.json`):

```
neobrutal-chat/              ← root project
├── package.json
├── .env
├── service-account.json     ← TARUH DI SINI!
├── firestore.rules
├── src/
└── ...
```

**Cara rename & pindah:**

**Mac/Linux:**
```bash
# Pindah ke folder project
cd neobrutal-chat

# Copy file yang sudah download ke root project dengan nama service-account.json
mv ~/Downloads/projekwhattsaf-firebase-adminsdk-*.json ./service-account.json

# Verifikasi
ls -la service-account.json
```

**Windows (PowerShell):**
```powershell
# Pindah ke folder project
cd neobrutal-chat

# Copy file dari Downloads ke root project
Move-Item "$env:USERPROFILE\Downloads\projekwhattsaf-firebase-adminsdk-*.json" ".\service-account.json"

# Verifikasi
Get-ChildItem service-account.json
```

### 4c. (Alternatif) Pakai Env Var

Kalau Anda lebih suka pakai env var (misal untuk deployment), jalankan script helper:

```bash
node scripts/load-service-account.js
```

Outputnya berupa string JSON yang bisa Anda copy ke file `.env`:
```
FIREBASE_SERVICE_ACCOUNT={"type":"service_account","project_id":"projekwhattsaf",...}
```

Atau langsung auto-update `.env`:
```bash
node scripts/load-service-account.js --apply
```

### 4d. Verifikasi Service Account

File `service-account.json` Anda harus berisi (kira-kira):
```json
{
  "type": "service_account",
  "project_id": "projekwhattsaf",
  "private_key_id": "...",
  "private_key": "-----BEGIN PRIVATE KEY-----\n...\n-----END PRIVATE KEY-----\n",
  "client_email": "firebase-adminsdk-xxxxx@projekwhattsaf.iam.gserviceaccount.com",
  "client_id": "...",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  ...
}
```

⚠️ **JANGAN PERNAH** commit file ini ke Git! Sudah ada di `.gitignore`.

---

## 🚀 Step 5: Run Aplikasi

Buka **2 terminal** (atau 2 tab di terminal yang sama):

### Terminal 1: Jalankan Socket.io Service (Real-time)

```bash
cd neobrutal-chat/mini-services/chat-service
bun install
bun run dev
```

Output yang benar:
```
[chat-service] WebSocket server running on port 3003
```

**Biarkan terminal ini tetap berjalan** (jangan di-close).

### Terminal 2: Jalankan Next.js App

```bash
cd neobrutal-chat
bun run dev
```

Output yang benar:
```
▲ Next.js 16.1.3 (Turbopack)
- Local:        http://localhost:3000
✓ Ready in xxx ms
```

**Biarkan terminal ini tetap berjalan** (jangan di-close).

---

## 🌐 Step 6: Buka Aplikasi di Browser

Buka **http://localhost:3000** di browser.

Anda akan melihat halaman register/login Neobrutal Chat.

### Register Akun Pertama (Jadi Superadmin)

1. Klik tombol **"Belum punya akun? Daftar"**
2. Isi form:
   - **Username**: `admin` (atau username lain, 3-20 huruf kecil)
   - **Email**: email Anda (misal `admin@test.com`)
   - **Password**: minimal 6 karakter
3. Klik **Daftar**
4. Setelah berhasil, halaman akan reload dan Anda masuk ke aplikasi

### Test Kirim Pesan

1. Klik tab **🌍 Global** di sidebar kiri
2. Ketik pesan di kolom input
3. Klik tombol kirim (panah →)
4. Pesan akan muncul real-time

---

## ✅ Cek Semua Berfungsi

| Fitur | Cara Test |
|-------|-----------|
| Register/Login | Daftar akun → harus masuk ke app |
| Profil | Klik avatar Anda → bisa edit nama & bio |
| Global Chat | Tab 🌍 → kirim pesan → muncul real-time |
| DM Private | Cari user via Ctrl+K → klik → kirim DM |
| Stories | Klik "Story kamu" → buat story text |
| Group | Tab 👥 → "+ Buat Grup" → isi form |
| Channel | Tab 📢 → "+ Buat" → isi form |
| Voice Note | Di chat → klik ikon mikrofon |
| Voice Call | Di DM → klik ikon telepon |
| Admin Panel | Klik ikon shield (🛡️) di header |
| Dark Mode | Klik ikon bulan/matahari di header |

---

## 🐛 Troubleshooting

### Error: "Missing or insufficient permissions"

**Penyebab:** Firestore security rules belum di-setup.

**Solusi:**
1. Buka Firebase Console → Firestore Database → Rules
2. Copy paste isi `firestore.rules` → Publish

### Error: "FIREBASE_SERVICE_ACCOUNT not set" atau API 500

**Penyebab:** Service account belum dikonfigurasi.

**Solusi:**
1. Download service account JSON (lihat Step 4a)
2. Taruh di root project dengan nama `service-account.json` (lihat Step 4b)
3. Restart Next.js dev server (Ctrl+C di terminal 2, lalu `bun run dev` lagi)

### Error: "firebase/compat/app not found" atau module error

**Penyebab:** Dependencies belum diinstall semua.

**Solusi:**
```bash
# Di root project
bun install
cd mini-services/chat-service && bun install && cd ..
```

### Socket.io tidak connect

**Penyebab:** Chat-service belum jalan.

**Solusi:**
1. Pastikan Terminal 1 masih jalan (`[chat-service] WebSocket server running on port 3003`)
2. Kalau sudah di-close, jalankan lagi:
   ```bash
   cd mini-services/chat-service
   bun run dev
   ```

### Real-time chat tidak update

**Penyebab:** Anda akses dari port 3000 langsung, bukan lewat Caddy gateway.

**Solusi:**
- Akses via `http://localhost:3000` (HTTP) — socket.io akan pakai polling fallback
- Atau pakai Caddy gateway port 81 (lebih baik untuk WebSocket)

### Upload media gagal

**Penyebab:** Firebase Storage belum di-setup atau rules belum di-publish.

**Solusi:**
1. Firebase Console → Storage → Get started
2. Tab Rules → copy paste `storage.rules` → Publish

### Voice/Video call gagal

**Penyebab:** Browser butuh izin mikrofon/kamera, atau HTTPS wajib.

**Solusi:**
1. Klik ikon 🔒 di address bar browser
2. Allow mikrofon & kamera
3. Refresh halaman
4. Pastikan akses via `localhost` atau HTTPS

---

## 🎯 Quick Start (One-Liner)

Kalau semua sudah setup (Firebase Console + service-account.json), Anda bisa jalankan semua dengan satu command:

```bash
# Di terminal 1 (chat-service)
cd neobrutal-chat/mini-services/chat-service && bun install && bun run dev

# Di terminal 2 (Next.js)
cd neobrutal-chat && bun install && bun run dev
```

Lalu buka http://localhost:3000

---

## 📞 Butuh Bantuan?

Kalau ada error, cek:
1. **Terminal 1** — ada error chat-service?
2. **Terminal 2** — ada error Next.js?
3. **Browser Console** (F12 → Console) — ada error JS?
4. **Firebase Console** — Firestore Database ada data?

Pesan error biasanya sudah cukup informatif. Kalau masih bingung, kirim screenshot error ke saya.
